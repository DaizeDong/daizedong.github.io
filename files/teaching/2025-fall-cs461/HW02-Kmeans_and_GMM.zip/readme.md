# CS461 Recitation 04 - Homework 2 (K-Means and GMM)

_Daize Dong, Rutgers University, Oct 6, 2025_

## Overview

Today we will be working on a programming assignment that involves:

- Implementing the K-Means.
    - Random and K-Means++ initialization.
    - Data assignment step and centroids update step.
- Implementing the Gaussian Mixture Models (GMM).
    - Random initialization.
    - E-step and M-step in Expectation-Maximization (EM) algorithm.
- Using the above algorithms to compress images.

## Arrangement

- Assignment overview
- Code review
    - Image compression pipeline
    - K-Means algorithm
    - GMM algorithm
- QA

## Key Points

<p align="left"><img src="kmeans_vs_gmm.png" alt="kmeans_vs_gmm" width="400"/></p>

- K-Means:
    - uses **discrete** assignments to clusters;
    - involves **distance computation** and **centroid updates**;
    - faster but less flexible;
    - sensitive to initialization, but can be improved with K-Means++.
- Gaussian Mixture Models (GMM):
    - uses **continuous** probabilities to assign data points to clusters;
    - involves **probability computation** (E-step) and **parameter updates** (M-step);
    - slower due to more complex computations;
    - more flexible, can model complex distributions.

## Hints on Coding

See [hints.md](hints.md).

## References

Homework 2 Link: https://firner.com/presentations/cs461/homework2.html

**Scoring:**

- 60% credit for saving a codebook with either k-means or a mixture of gaussians.
- 10% for printing out the reconstruction error.
- 15% credit decoding that codebook.
- 15% credit for having both clustering algorithms working.
- 10% credit for improving k-means into k-means++.

These sum to 110%.