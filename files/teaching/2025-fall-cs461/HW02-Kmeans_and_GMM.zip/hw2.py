import argparse

import numpy as np
from PIL import Image

from kmeans import k_means
from mixture_of_experts import MinimalMixtureOfExperts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--compress",
        required=False,
        type=str,
        default=None,
        help="A path to a file that will be compressed."
    )
    parser.add_argument(
        "--decompress",
        required=False,
        type=str,
        default=None,
        help="A path to a file that will be decompressed."
    )
    parser.add_argument(
        "--clusters",
        required=False,
        type=int,
        default=20,
        help="The number of clusters to use for compression."
    )
    parser.add_argument(
        "--model",
        required=False,
        choices=["kmeans", "kmeans++", "mixture"],
        default="kmeans",
        help="Use kmeans++ or a mixture of gaussians with soft clustering."
    )
    parser.add_argument(
        "--output",
        required=True,
        type=str,
        default=None,
        help="The path to use when saving the output."
    )

    args = parser.parse_args()

    if args.compress:
        """
        input: image file
        output: compressed npz file
        """
        img = Image.open(args.compress)
        img_array = np.array(img).astype(float)
        X = np.reshape(img_array, (img_array.shape[0] * img_array.shape[1], -1))  # Flatten the image

        print(f"Image {args.compress} shape: {img_array.shape}, flattened shape: {X.shape}")

        if args.model in ("kmeans", "kmeans++"):
            assignments, means = k_means(
                X,
                K=args.clusters,
                init=args.model,
                max_iters=100,
                tol=1e-4,
            )

        elif args.model == "mixture":
            assignments, means = MinimalMixtureOfExperts(
                K=args.clusters,
                max_iters=100,
                tol=1e-4,
                eps=1e-6,
            ).fit(X)

        else:
            raise NotImplementedError(f"Unknown model {args.model}")

        # -----------------------------------------------------------
        # TODO:
        # 1. Save the assignments, means, and original image shape to a npz file
        # 2. Compute construction loss (MSE between original and reconstructed image)
        # Hint: np.savez_compressed can be useful
        # -----------------------------------------------------------

    if args.decompress:
        """
        input: compressed npz file
        output: image file
        """

        # -----------------------------------------------------------
        # TODO:
        # 1. Save the assignments, means, and original image shape to a npz file
        # 2. Compute construction loss (MSE between original and reconstructed image)
        # Hint: np.savez_compressed can be useful
        # -----------------------------------------------------------
        pass


if __name__ == "__main__":
    main()
