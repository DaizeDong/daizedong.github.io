from typing import Optional

import numpy as np


class MinimalMixtureOfExperts:
    """
    Minimal Mixture-of-Experts (MoE) for clustering.
    Each expert is a diagonal-covariance Gaussian.

    Args:
      K         : number of experts (clusters)
      max_iters : maximum number of EM iterations
      tol       : tolerance for convergence (based on log-likelihood improvement)
      eps       : small numerical stabilizer for variances
    """

    def __init__(self, K: int, max_iters: int = 100, tol: float = 1e-4, eps: float = 1e-6):
        self.K = K
        self.max_iters = max_iters
        self.tol = tol
        self.eps = eps

        # Parameters learned by EM
        self.pi: Optional[np.ndarray] = None  # Mixing weights, shape (K,)
        self.gauss_mu: Optional[np.ndarray] = None  # Means, shape (K, D)
        self.gauss_sigma_diag: Optional[np.ndarray] = None  # Diagonal variances, shape (K, D)

    def _initialize_params(self, X: np.ndarray) -> None:
        """
        Initialize mixing weights, means, and diagonal variances.

        Strategy:
          - pi: uniform 1/K
          - mu: random K samples from data
          - sigma_diag: global data variance (per-dim), replicated for each expert
        """
        N, D = X.shape

        # Uniform priors
        self.pi = np.full(self.K, 1.0 / self.K, dtype=float)  # (K,)

        # -----------------------------------------------------------
        # TODO:
        # 1. pick K random points as initial centers
        # 2. global variance of data, replicated for each expert as initial variance
        self.gauss_mu, self.gauss_sigma_diag = None, None  # (K, D), (K, D)
        # -----------------------------------------------------------

    @staticmethod
    def _log_gaussian_diag(X: np.ndarray, mu: np.ndarray, sigma_diag: np.ndarray, eps: float = 1e-6) -> np.ndarray:
        """
        Compute log-likelihood under a single diagonal-covariance Gaussian expert for all samples.

        Args:
          X          : (N, D) data matrix
          mu         : (D,)   expert mean
          sigma_diag : (D,)   expert diagonal variances (must be > 0)
          eps        : small numerical stabilizer for variances

        Returns:
          log_likelihood : (N,) log-likelihood per sample
        """
        N, D = X.shape

        # Stabilize variances to avoid divide-by-zero or log(0)
        var = sigma_diag + eps  # (D,)
        x_mu = X - mu  # (N, D)

        # Compute log-likelihood
        # -----------------------------------------------------------
        # TODO:
        # 1. Compute the Mahalanobis distance term
        # 2. Compute the constant term
        # 3. Combine to get log-likelihood
        log_likelihood = None  # (N,)
        # -----------------------------------------------------------

        return log_likelihood

    def _e_step(self, X: np.ndarray) -> tuple[np.ndarray, float]:
        """
        E-step: compute responsibilities (posterior over experts) for each sample,
        and the total data log-likelihood.

        Returns:
          gamma                 : (N, K) responsibilities; rows sum to 1
          total_log_likelihood  : float, sum_i log( sum_k pi_k * N_k(x_i) )
        """
        N, D = X.shape

        # log p(x | z=K) for all experts
        log_likelihood_k = np.empty((N, self.K), dtype=float)
        for K in range(self.K):
            log_likelihood_k[:, K] = self._log_gaussian_diag(X, self.gauss_mu[K], self.gauss_sigma_diag[K])

        # -----------------------------------------------------------
        # TODO:
        # 1. Compute log_num = log [ pi_k * p(x | K) ] for all samples and experts
        # 2. Compute log_den = log p(x) using log-sum-exp trick
        # 3. Compute log responsibilities log_gamma = log_num - log_den
        # 4. Exponentiate to get gamma, and normalize rows to sum to 1

        # gamma: (N, K) responsibilities
        # Total log-likelihood is sum of log p(x_i) over all samples
        gamma, total_log_likelihood = None, None  # (N, K) responsibilities
        # -----------------------------------------------------------

        return gamma, total_log_likelihood

    def _m_step(self, X: np.ndarray, gamma: np.ndarray) -> None:
        """
        M-step: update pi, means, and diagonal variances using responsibilities.
        """
        N, D = X.shape

        # -----------------------------------------------------------
        # TODO:
        # 1. Compute N_k for each expert
        # 2. Update means mu_k
        # 3. Update diagonal variances sigma_k^2 with variance flooring
        # 4. Update mixing weights pi_k
        # -----------------------------------------------------------

    def fit(self, X: np.ndarray, log_likelihood_threshold: float = 1.0) -> tuple[np.ndarray, np.ndarray]:
        """
        Run EM to estimate parameters. Stops early when log-likelihood improvement is tiny.

        Args:
            X                        : (N, D) data points to cluster
            log_likelihood_threshold : threshold for log-likelihood improvement to stop EM
        Returns:
            assignments : (N,) cluster assignments for each point
            centers     : (K, D) cluster centers
        """
        # 1) Initialize parameters
        self._initialize_params(X)

        # 2) Run EM iterations
        print(f"Starting EM training with K={self.K}...")
        past_total_log_likelihood = -np.inf

        for t in range(1, self.max_iters + 1):
            # 3) E-step: Compute responsibilities and log-likelihood
            gamma, total_log_likelihood = self._e_step(X)
            print(f"Iteration {t}/{self.max_iters} | Log-Likelihood: {total_log_likelihood:.6f}")

            # 4) M-step: Update parameters
            self._m_step(X, gamma)

            # Convergence check
            if total_log_likelihood - past_total_log_likelihood < log_likelihood_threshold:
                print("EM converged.")
                break
            else:
                past_total_log_likelihood = total_log_likelihood

        # Final assignments
        assignments = self.predict(X)
        return assignments, self.gauss_mu

    def predict(self, X: np.ndarray) -> np.ndarray:
        gamma, _ = self._e_step(X)
        return np.argmax(gamma, axis=1)
