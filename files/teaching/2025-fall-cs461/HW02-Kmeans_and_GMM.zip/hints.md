# Hints on Coding

## K-Means

**K-Means** alternates between assigning each point to its nearest center and updating centers as the mean of assigned points, minimizing total within-cluster variance.

**Initialization (K-Means++):**

1. Pick the first center at random.
2. For each point, compute its squared distance $D²(x)$ to the nearest chosen center.
3. Select the next center with probability ∝ $D²(x)$.
4. Repeat until $K$ centers are chosen.
   This spreads centers apart for faster, more stable convergence.

**Iteration:**

- **Assignment:**  
  Each sample joins its closest cluster: $ c_i = \arg\min_k \|x_i - \mu_k\|^2 $.
- **Update:**  
  Move each center to its cluster mean: $ \mu_k = \frac{1}{N_k} \sum_{i: c_i=k} x_i $.

Repeat until centers stabilize or the loss $ J = \sum_i \|x_i - \mu_{c_i}\|^2 $ stops decreasing.

## Gaussian Mixture Models (GMM)

The Expectation–Maximization (EM) algorithm alternates between **estimating hidden cluster assignments** and **updating model parameters** to maximize the data likelihood under a probabilistic mixture model.

**E-step (Expectation):**  
Given the current parameters (mixing weights $π_k$, means $μ_k$, and diagonal variances $σ_k²$), compute each sample’s *responsibility*

$$$
\gamma_{ik} = P(z_i = k \mid x_i)
$$$

which measures how likely expert *k* generated sample *xᵢ*.  
This is done by evaluating Gaussian likelihoods for all experts, adding the log priors $log π_k$, and normalizing with a **log-sum-exp** to ensure numerical stability.

**M-step (Maximization):**  
Using the responsibilities as soft weights, update each expert’s parameters:

- **Mixing weights:** $ π_k = N_k / N $, where $ N_k = \sum_i \gamma_{ik} $
- **Means:** $ \mu_k = (\sum_i \gamma_{ik} x_i) / N_k $
- **Variances:** $ \sigma_k^2 = (\sum_i \gamma_{ik} (x_i - \mu_k)^2) / N_k $

Each iteration increases (or maintains) the total log-likelihood

$$$
\mathcal{L} = \sum_i \log \sum_k π_k \, \mathcal{N}(x_i \mid \mu_k, \sigma_k^2)
$$$

until convergence, forming a *soft clustering* where every sample belongs to each expert with probability $γ_ik$.
