import numpy as np


def k_means(
    X: np.ndarray,
    K: int,
    init: str = "random",
    max_iters: int = 100,
    tol: float = 1e-4,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Lloyd's algorithm for k-means clustering.
    Args:
        X         : (N, D) data points to cluster
        K         : number of clusters
        init      : "random" or "kmeans++" initialization
        max_iters : maximum number of iterations
        tol       : tolerance for convergence (based on center movement)
    Returns:
        assignments : (N,) cluster assignments for each point
        centers     : (K, D) cluster centers
    """
    N, D = X.shape
    if K < 1 or K > N:
        raise ValueError("Number of clusters must be in [1, N]")

    # initialization
    if init == "random":
        # -----------------------------------------------------------
        # TODO: implement random init
        # -----------------------------------------------------------
        pass
    elif init == "kmeans++":
        # -----------------------------------------------------------
        # TODO: implement kmeans++ init
        # -----------------------------------------------------------
        pass
    else:
        raise ValueError(f"Unknown init method: {init}")

    # k-means iterations
    assignments = np.zeros(N, dtype=int)
    centers = np.zeros((K, D), dtype=float)

    # -----------------------------------------------------------
    # TODO: implement k-means iterations
    # 1. Assign each point to the nearest center
    # 2. Update centers as the mean of assigned points
    # 3. Check for convergence (if centers do not change more than tol)
    # 4. Stop if converged or max_iters reached
    # -----------------------------------------------------------

    return assignments, centers
