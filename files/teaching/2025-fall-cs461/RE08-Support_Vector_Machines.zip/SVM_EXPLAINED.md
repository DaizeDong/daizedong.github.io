# SVMs with Soft-Margin

This note distills the core theory to explain:

- How the soft-margin SVM works.
- What the Lagrange multipliers $ \alpha $ are.
- How they interact with the regularization parameter $ C $.



## 1. Problem Setup

We consider a binary classification dataset $ \{(x_i, y_i)\}_{i=1}^n $ with labels $ y_i \in \{-1, +1\} $. The linear decision function is
$$
f(x) = w^\top x + b, \qquad \hat y = \operatorname{sign}(f(x)).
$$

The <u>geometric margin</u> between the two parallel supporting hyperplanes is $ \frac{2}{\lVert w \rVert} $. Maximizing this margin is the key geometric idea behind SVMs.



## 2. Margins

### Hard-Margin

$$
\min_{w,b}\ \tfrac12\lVert w\rVert^2
\quad \text{s.t.} \quad y_i\,(w^\top x_i + b)\ \ge\ 1,\ \forall i.
$$

This maximizes the margin $ 2/\lVert w\rVert $ while classifying all training points correctly.

### Soft-Margin

To allow violations of the margin, introduce <u>slack variables</u> $ \xi_i \ge 0 $ and a <u>penalty parameter</u> $ C>0 $:
$$
\min_{w,b,\xi}\ \tfrac12\lVert w\rVert^2 + C\sum_{i=1}^n \xi_i
\quad \text{s.t.} \quad y_i\,(w^\top x_i + b)\ \ge\ 1 - \xi_i,\ \ \xi_i \ge 0.
$$

Equivalently, this is $L_2$ regularization + <u>hinge loss</u>:
$$
\min_{w,b}\ \tfrac12\lVert w\rVert^2 + C\sum_{i=1}^n \max\!\bigl(0,\, 1 - y_i f(x_i)\bigr).
$$

**Role of $ C $**

Trading off margin width and training errors.

- **Small $ C $:** the model is willing to tolerate violations (wider margin, more bias).
- **Large $ C $:** violations are penalized heavily (narrower margin, lower training error, higher overfitting risk).



## 3. Lagrange Multipliers

The Lagrangian dual with a kernel $K(x_i,x_j)=\phi(x_i)^\top\phi(x_j)$ is
$$
\max_{\alpha \in \mathbb{R}^n}\ \sum_{i=1}^n \alpha_i\ -\ \tfrac12 \sum_{i=1}^n\sum_{j=1}^n \alpha_i\alpha_j y_i y_j\, K(x_i,x_j)
$$
$$
\text{s.t.}\quad 0 \le \alpha_i \le C,\ \ \sum_{i=1}^n \alpha_i y_i = 0.
$$

The <u>Lagrange multipliers</u> $ \alpha_i $ determine the classifier:

- For a linear kernel, $ w = \sum_{i=1}^n \alpha_i y_i x_i $.
- The bias can be computed from any free <u>support vector</u>:
  $$
  b = y_i - \sum_{j=1}^n \alpha_j y_j K(x_j,x_i)\quad \text{for any } i \text{ with } 0<\alpha_i<C.
  $$
- The decision function is
  $$
  f(x) = \sum_{i=1}^n \alpha_i y_i K(x_i, x) + b.
  $$



## 4. Support Vectors

According to the value of  $ \alpha_i $, we know whether point $i$ affects the model:

- **$ \alpha_i = 0 $:** do not affect $w,b$ at all.

- **$ \alpha_i > 0 $:** <u>support vectors</u>. These points appear in the model.

  Furthermore, if we take $ C $ into account, we have two types of support vectors.

  - **$ 0 < \alpha_i < C $:** <u>free support vectors</u>. These points lie exactly on the margin.

  - **$ \alpha_i = C $:** <u>bounded support vectors</u>. These points either lie inside the margin or are misclassified.
  
  - **$ \alpha_i > C $:** impossible due to the dual constraint.
