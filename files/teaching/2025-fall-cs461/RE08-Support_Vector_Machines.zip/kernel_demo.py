import warnings

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.widgets import Slider, RadioButtons
from sklearn.svm import SVC

from svm.data import make_linear_separable, make_nonlinear
from svm.plotting import plot_decision_2d


def _ensure_interactive_backend():
    """Switch to an interactive backend if the current one is headless/inline."""
    backend = matplotlib.get_backend().lower()
    if "inline" in backend or "agg" in backend:
        for candidate in ("QtAgg", "Qt5Agg", "TkAgg", "MacOSX"):
            try:
                matplotlib.use(candidate, force=True)
                return
            except Exception:
                continue
        warnings.warn(
            "No GUI Matplotlib backend is available; the sliders will act like a static figure."
        )


_ensure_interactive_backend()

# Parallel thread count
N_JOBS = -1  # -1 means use all available CPU cores

# Increase all font sizes
plt.rcParams['font.size'] = 12
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['axes.titlesize'] = 14
plt.rcParams['xtick.labelsize'] = 11
plt.rcParams['ytick.labelsize'] = 11
plt.rcParams['legend.fontsize'] = 11
plt.rcParams['figure.titlesize'] = 14


def build_dataset(name, seed=0, n=80):
    if name == "linear":
        per_class = max(5, n // 2)
        X, y = make_linear_separable(n_per_class=per_class, seed=seed)
    elif name == "moons":
        X, y = make_nonlinear("moons", n=n, noise=0.15, seed=seed)
    elif name == "circles":
        X, y = make_nonlinear("circles", n=n, noise=0.08, seed=seed)
    else:
        raise ValueError("unknown dataset")
    return X, y


def main():
    # Initial state
    dataset_name = "linear"
    kernel = "linear"
    C = 1.0
    gamma = 1.0  # Ignored for the linear kernel
    degree = 3
    n_samples = 80
    X0, y0 = build_dataset(dataset_name, n=n_samples)

    # Figure layout
    fig, ax = plt.subplots(figsize=(6.2, 5.4))
    plt.subplots_adjust(left=0.20, bottom=0.30)

    # Initial fit
    # Note: SVC does not support n_jobs parameter because underlying libsvm does not support multithreaded training
    clf = SVC(C=C, kernel=kernel, gamma=gamma if kernel != "linear" else "scale", degree=degree)
    clf.fit(X0, y0)
    plot_decision_2d(
        ax,
        clf,
        X0,
        y0,
        C=C,
        title=f"{dataset_name} | {kernel} | C={C:g}, N={len(X0)}",
        n_jobs=N_JOBS,
    )
    ax.legend(loc='upper right', fontsize=10, framealpha=0.9)

    # Controls panel
    axcolor = "0.95"
    ax_C = plt.axes([0.20, 0.22, 0.65, 0.03], facecolor=axcolor)
    ax_gamma = plt.axes([0.20, 0.18, 0.65, 0.03], facecolor=axcolor)
    ax_degree = plt.axes([0.20, 0.14, 0.65, 0.03], facecolor=axcolor)
    ax_samples = plt.axes([0.20, 0.10, 0.65, 0.03], facecolor=axcolor)

    s_C = Slider(ax_C, "log10 C", -3.0, 3.0, valinit=np.log10(C), valstep=0.1)
    s_gamma = Slider(ax_gamma, "gamma", 0.01, 10.0, valinit=gamma, valstep=0.01)
    s_degree = Slider(ax_degree, "degree", 2, 8, valinit=degree, valstep=1)
    s_samples = Slider(ax_samples, "samples", 40, 400, valinit=n_samples, valstep=10)

    def update_control_visibility():
        kernel_val = r_kernel.value_selected

        show_gamma = kernel_val != "linear"
        s_gamma.ax.set_visible(show_gamma)
        s_gamma.set_active(show_gamma)

        show_degree = kernel_val == "poly"
        s_degree.ax.set_visible(show_degree)
        s_degree.set_active(show_degree)

    r_kernel = RadioButtons(plt.axes([0.02, 0.48, 0.18, 0.16], facecolor=axcolor), ("linear", "rbf", "poly"))
    r_dataset = RadioButtons(plt.axes([0.02, 0.30, 0.18, 0.16], facecolor=axcolor), ("linear", "moons", "circles"))

    def redraw(_=None):
        update_control_visibility()
        ax.clear()
        C_val = 10 ** s_C.val
        kernel_val = r_kernel.value_selected
        ds_val = r_dataset.value_selected
        gamma_val = s_gamma.val
        degree_val = int(s_degree.val)
        n_val = int(s_samples.val)
        Xb, yb = build_dataset(ds_val, n=n_val)

        clf = SVC(
            C=C_val,
            kernel=kernel_val,
            gamma=(gamma_val if kernel_val != "linear" else "scale"),
            degree=degree_val
        )
        clf.fit(Xb, yb)
        title = f"{ds_val} | {kernel_val} | C={C_val:.3g}, N={len(Xb)}"
        if kernel_val != "linear":
            title += f", gamma={gamma_val:.3g}"
        if kernel_val == "poly":
            title += f", degree={degree_val}"
        plot_decision_2d(ax, clf, Xb, yb, C=C_val, title=title, n_jobs=N_JOBS)
        ax.legend(loc='upper right', fontsize=10, framealpha=0.9)
        fig.canvas.draw_idle()

    # Event bindings
    s_C.on_changed(redraw)
    s_gamma.on_changed(redraw)
    s_degree.on_changed(redraw)
    s_samples.on_changed(redraw)
    r_kernel.on_clicked(redraw)
    r_dataset.on_clicked(redraw)

    update_control_visibility()

    plt.show()


if __name__ == "__main__":
    main()
