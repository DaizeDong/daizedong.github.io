# CS461 Recitation 08 - Support Vector Machines

_Daize Dong, Rutgers University, Nov. 03, 2025_

## Overview

Today we will be working on a demo of Support Vector Machines (SVM) to classify data points in a 2D space. We will focus on the following tasks:

- What is $C$ and how does it deal with margin violations?
- How different kernels affect the SVM decision boundary?

## Background

Reference: [SVM_EXPLAINED.md](SVM_EXPLAINED.md)

### Hinge Loss and Regularization

$C$: hinge loss regularization strength.

- Smaller $C$ allows more margin violations, leading to a wider margin but potentially more misclassifications.
- Larger $C$ penalizes margin violations more heavily, resulting in a narrower margin that fits the training data more closely.

### Kernels

- **Linear Kernel**: $k=\langle x, x' \rangle$. Suitable for linearly separable data.
- **RBF Kernel**: $k=\exp(-\gamma ||x - x'||^2)$. Captures complex, non-linear relationships.
- **Polynomial Kernel**: $k=(\gamma \langle x, x' \rangle + r)^d$. Captures polynomial relationships.

_RBF: Radial Basis Function._

## Entry Points

| Script                                                 | Purpose                                                                                 |
|--------------------------------------------------------|-----------------------------------------------------------------------------------------|
| [c_parameter_comparison.py](c_parameter_comparison.py) | Generate a grid of SVM decision boundaries for different $\log_{10}C$ and noise counts. |
| [c_parameter_demo.py](c_parameter_demo.py)             | Interactive matplotlib dashboard with sliders for $\log_{10}C$ and noise count.         |
| [kernel_demo.py](kernel_demo.py)                       | Interactive matplotlib dashboard with sliders for all kinds of hyperparameters.         |

## $C$ Parameter Demo

### Interactive

```bash
python c_parameter_demo.py
```

The script will open a matplotlib window with sliders to adjust the following parameters:

- **log10 C**: sweep the regularization strength.
- **noise count**: number of intruder points to add to the dataset.

### Grid Comparison

```bash
python c_parameter_comparison.py \
  --n-per-class 25 \
  --gap 3.0 \
  --seed 23333 \
  --Cs 1.0 10.0 100.0 1000.0 10000.0 \
  --noise-counts 0 10 20 30 \
  --save-path outputs/c_parameter_demo.png
```

The script builds a grid where rows correspond to different intruder counts and columns to different $C$.

- `--n-per-class`: controls how many points per class to generate.
- `--gap`: controls the distance between the two classes.
- `--Cs`: controls which regularization strengths to try.
- `--noise-counts`: controls how many intruder points to add to the dataset.

## Kernel Demo

```bash
python kernel_demo.py
```

This will open a matplotlib window with sliders to adjust the following parameters:

- **samples**: number of points in the generated dataset.
- **log10 C**: sweep the hinge loss regularization strength.
- **gamma**: only for RBF & polynomial kernels.
- **degree**: only for the polynomial kernel.
