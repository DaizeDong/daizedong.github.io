import warnings

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.widgets import Slider
from sklearn.svm import SVC

from svm.data import make_linear_separable, _fit_reference_hyperplane, _point_on_hyperplane
from svm.plotting import plot_decision_2d

# Ensure interactive backend
def _ensure_interactive_backend():
    """Switch to an interactive backend if the current one is headless/inline."""
    backend = matplotlib.get_backend().lower()
    if "inline" in backend or "agg" in backend:
        for candidate in ("QtAgg", "Qt5Agg", "TkAgg", "MacOSX"):
            try:
                matplotlib.use(candidate, force=True)
                return
            except Exception:
                continue
        warnings.warn(
            "No GUI Matplotlib backend is available; the sliders will act like a static figure."
        )


_ensure_interactive_backend()

# Increase all font sizes
plt.rcParams['font.size'] = 12
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['axes.titlesize'] = 14
plt.rcParams['xtick.labelsize'] = 11
plt.rcParams['ytick.labelsize'] = 11
plt.rcParams['legend.fontsize'] = 11
plt.rcParams['figure.titlesize'] = 14


def add_noise_points_to_opposite_class(X, y, k=5, seed=42):
    """
    Add noise points to the opposite class region, near the boundary.
    The noise points will be placed in the wrong class region (crossing the boundary).
    
    Parameters:
    -----------
    X : array-like, shape (n_samples, 2)
        Base linearly separable data
    y : array-like, shape (n_samples,)
        Labels (-1 or +1)
    k : int
        Number of noise points to add
    seed : int
        Random seed
    
    Returns:
    --------
    X_new : array-like, shape (n_samples + k, 2)
        Data with noise points added
    y_new : array-like, shape (n_samples + k,)
        Labels with noise points (wrong labels)
    """
    rng = np.random.RandomState(seed)
    
    # Fit a reference hyperplane to find the boundary
    w, b = _fit_reference_hyperplane(X, y, C=1e6)
    w_norm = np.linalg.norm(w)
    if w_norm == 0:
        raise ValueError("Degenerate hyperplane: ||w|| == 0")
    
    # Reference point on the hyperplane
    x0 = _point_on_hyperplane(w, b)
    n_hat = w / w_norm  # Normal vector pointing toward positive class
    t_hat = np.array([-n_hat[1], n_hat[0]])  # Tangential direction
    
    # Find the center of the negative class (to place noise points)
    neg_mask = (y == -1)
    pos_mask = (y == 1)
    
    if neg_mask.sum() > 0 and pos_mask.sum() > 0:
        neg_center = X[neg_mask].mean(axis=0)
        pos_center = X[pos_mask].mean(axis=0)
        
        # Determine which side to place noise points
        # Place noise points labeled as +1 in the negative class region (near boundary)
        # Place noise points labeled as -1 in the positive class region (near boundary)
        
        # Data span
        xmin, ymin = X.min(axis=0) - 0.5
        xmax, ymax = X.max(axis=0) + 0.5
        box_corners = np.array([[xmin, ymin], [xmax, ymax]])
        diag = np.linalg.norm(box_corners[1] - box_corners[0])
        
        # Margin width
        margin = 1.0 / w_norm
        
        noise_points = []
        noise_labels = []
        
        # Place points on the negative side (labeled as +1) and positive side (labeled as -1)
        # Half points in negative region with +1 label, half in positive region with -1 label
        k_pos_noise = k // 2  # Points labeled +1 in negative region
        k_neg_noise = k - k_pos_noise  # Points labeled -1 in positive region
        
        # Sample along the tangent
        ss = np.linspace(-0.5 * diag, 0.5 * diag, num=max(3, k))
        rng.shuffle(ss)
        
        # Add noise points labeled +1 in negative class region (near boundary)
        for i in range(k_pos_noise):
            s = ss[i] if i < len(ss) else rng.uniform(-0.5 * diag, 0.5 * diag)
            # Start from negative class center, move toward boundary
            direction_to_boundary = x0 - neg_center
            direction_to_boundary = direction_to_boundary / np.linalg.norm(direction_to_boundary) if np.linalg.norm(direction_to_boundary) > 0 else -n_hat
            
            # Place point in negative region but close to boundary
            # Distance from negative center to boundary
            dist_to_boundary = np.abs(np.dot(neg_center - x0, n_hat))
            # Place at 70-90% of the way from center to boundary
            frac = rng.uniform(0.7, 0.9)
            p = neg_center + frac * dist_to_boundary * direction_to_boundary
            
            # Add tangential offset
            p = p + s * t_hat * 0.3
            # Add small jitter
            p = p + rng.normal(scale=0.1 * margin, size=2)
            
            noise_points.append(p)
            noise_labels.append(1)  # Wrong label for negative region
        
        # Add noise points labeled -1 in positive class region (near boundary)
        for i in range(k_neg_noise):
            s = ss[k_pos_noise + i] if (k_pos_noise + i) < len(ss) else rng.uniform(-0.5 * diag, 0.5 * diag)
            # Start from positive class center, move toward boundary
            direction_to_boundary = x0 - pos_center
            direction_to_boundary = direction_to_boundary / np.linalg.norm(direction_to_boundary) if np.linalg.norm(direction_to_boundary) > 0 else n_hat
            
            # Place point in positive region but close to boundary
            dist_to_boundary = np.abs(np.dot(pos_center - x0, n_hat))
            frac = rng.uniform(0.7, 0.9)
            p = pos_center + frac * dist_to_boundary * direction_to_boundary
            
            # Add tangential offset
            p = p + s * t_hat * 0.3
            # Add small jitter
            p = p + rng.normal(scale=0.1 * margin, size=2)
            
            noise_points.append(p)
            noise_labels.append(-1)  # Wrong label for positive region
        
        if k > 0:
            X_new = np.vstack([X, np.array(noise_points)])
            y_new = np.concatenate([y, np.array(noise_labels, dtype=int)])
        else:
            X_new = X.copy()
            y_new = y.copy()
        
        return X_new, y_new
    else:
        return X.copy(), y.copy()


def main():
    # Generate linearly separable base data
    seed = 42
    n_per_class = 25
    X_base, y_base = make_linear_separable(
        n_per_class=n_per_class,
        gap=3.5,
        spread=1.0,
        seed=seed
    )

    # Initial state
    log10_C = 0.0  # Start with C=1.0
    C = 10.0 ** log10_C
    n_noise = 5  # Initial number of noise points

    # Generate initial dataset with noise points
    X, y = add_noise_points_to_opposite_class(X_base, y_base, k=n_noise, seed=seed)

    # Figure layout
    fig, ax = plt.subplots(figsize=(8, 6))
    plt.subplots_adjust(left=0.15, bottom=0.30)

    # Initial fit
    clf = SVC(C=C, kernel="linear", max_iter=10000)
    clf.fit(X, y)

    # Check convergence
    converged = clf.n_iter_ < clf.max_iter
    
    plot_decision_2d(
        ax,
        clf,
        X,
        y,
        C=C,
        title=f"Linear SVM with Noise | C={C:.3g} | Noise: {n_noise} | Converged: {converged}",
        n_jobs=-1,
    )
    ax.legend(loc='upper right', fontsize=10, framealpha=0.9)

    # Controls panel
    axcolor = "0.95"
    ax_C = plt.axes([0.15, 0.20, 0.75, 0.03], facecolor=axcolor)
    ax_noise = plt.axes([0.15, 0.15, 0.75, 0.03], facecolor=axcolor)

    s_C = Slider(ax_C, "log₁₀ C", -2.0, 4.0, valinit=log10_C, valstep=0.1)
    s_noise = Slider(ax_noise, "Noise Points", 0, 20, valinit=n_noise, valstep=1)

    def update(val):
        ax.clear()
        log10_C_val = s_C.val
        C_val = 10.0 ** log10_C_val
        n_noise_val = int(s_noise.val)
        
        # Regenerate dataset with new noise point count
        X_new, y_new = add_noise_points_to_opposite_class(
            X_base, y_base, 
            k=n_noise_val, 
            seed=seed
        )
        
        # Fit with new C value and noise points
        clf = SVC(C=C_val, kernel="linear", max_iter=10000)
        clf.fit(X_new, y_new)
        
        # Check convergence
        converged = clf.n_iter_ < clf.max_iter
        if not converged:
            status_text = "NOT CONVERGED (max_iter reached)"
            title_color = "red"
        else:
            status_text = "Converged"
            title_color = "black"
        
        plot_decision_2d(
            ax,
            clf,
            X_new,
            y_new,
            C=C_val,
            title=f"Linear SVM with Noise | C={C_val:.3g} | Noise: {n_noise_val} | {status_text}",
            n_jobs=-1,
        )
        
        # Add legend
        ax.legend(loc='upper right', fontsize=10, framealpha=0.9)
        
        # Update title color if not converged
        ax.title.set_color(title_color)
        
        # Add warning text if not converged
        if not converged:
            ax.text(0.5, 0.02, "Warning: Solution may be unstable! Try reducing C or noise points.",
                   transform=ax.transAxes, ha="center", va="bottom",
                   fontsize=11, bbox=dict(boxstyle="round,pad=0.5", fc="yellow", ec="red", alpha=0.8))
        
        fig.canvas.draw_idle()

    # Event bindings
    s_C.on_changed(update)
    s_noise.on_changed(update)

    plt.show()


if __name__ == "__main__":
    main()

