import numpy as np
from sklearn.datasets import make_blobs, make_moons, make_circles
from sklearn.svm import SVC


def make_linear_separable(n_per_class=25, gap=3.5, spread=1.0, seed=0):
    """
    Generate a roughly linearly separable 2D dataset (two Gaussian blobs).
    Labels are {-1, +1}.
    """
    centers = np.array([[-gap / 2, -gap / 2], [gap / 2, gap / 2]])
    X, y01 = make_blobs(
        n_samples=2 * n_per_class,
        centers=centers,
        cluster_std=spread,
        random_state=seed,
    )
    y = np.where(y01 == 0, -1, 1)
    return X, y


def make_nonlinear(name="moons", n=200, noise=0.15, seed=0):
    """
    Generate a nonlinearly separable dataset: moons or circles.
    Labels are {-1, +1}.
    """
    if name == "moons":
        X, y01 = make_moons(n_samples=n, noise=noise, random_state=seed)
    elif name == "circles":
        X, y01 = make_circles(n_samples=n, noise=noise, factor=0.5, random_state=seed)
    else:
        raise ValueError("dataset must be 'moons' or 'circles'")
    y = np.where(y01 == 0, -1, 1)
    return X, y


def make_linearly_inseparable(n_per_class=25, overlap=0.5, spread=1.2, seed=0):
    """
    Generate a linearly inseparable 2D dataset by creating overlapping blobs.
    This is useful for demonstrating how the C parameter affects SVM behavior
    when data cannot be perfectly separated.
    
    Labels are {-1, +1}.
    
    Parameters:
    -----------
    n_per_class : int
        Number of samples per class
    overlap : float
        Controls how much the two classes overlap (smaller = more overlap)
    spread : float
        Standard deviation of the Gaussian blobs (larger = more spread/overlap)
    seed : int
        Random seed for reproducibility
    """
    rng = np.random.RandomState(seed)
    # Generate two blobs that overlap significantly
    centers = np.array([[-overlap, 0], [overlap, 0]])
    X, y01 = make_blobs(
        n_samples=2 * n_per_class,
        centers=centers,
        cluster_std=spread,
        random_state=seed,
    )
    # Add some noise to make it more clearly inseparable
    X += rng.normal(0, 0.2, X.shape)
    y = np.where(y01 == 0, -1, 1)
    return X, y


def _fit_reference_hyperplane(X, y, C=1e6):
    """
    Fit an almost hard-margin linear SVM with a very large C to extract (w, b).
    Used only to build geometric references for the margin intruders.
    """
    clf = SVC(C=C, kernel="linear")
    clf.fit(X, y)
    w = clf.coef_.ravel()  # shape (2,)
    b = clf.intercept_[0]
    return w, b


def _point_on_hyperplane(w, b):
    """
    Find a point x0 on the hyperplane such that w·x0 + b = 0.
    We take x0 = -b * w / ||w||^2.
    """
    w_norm2 = np.dot(w, w)
    if w_norm2 == 0:
        raise ValueError("w has zero norm, degenerate hyperplane.")
    return -b * w / w_norm2


def add_margin_intruders(
    X,
    y,
    k=3,
    label_of_intruders=1,
    offset_ratio=0.6,
    seed=42,
):
    """
    Add k "intruder" points inside the margin near the current linear separating hyperplane.
    - label_of_intruders: label assigned to the injected points (+1 or -1)
    - Points are placed on the geometrically opposite side to ensure they trespass the margin.
    - offset_ratio: penetration depth relative to the margin width (1 / ||w||).

    Returns: X_new, y_new
    """
    rng = np.random.RandomState(seed)
    w, b = _fit_reference_hyperplane(X, y, C=1e6)
    w_norm = np.linalg.norm(w)
    if w_norm == 0:
        raise ValueError("Degenerate hyperplane: ||w|| == 0")

    # Reference point on the hyperplane and tangential/normal bases
    x0 = _point_on_hyperplane(w, b)
    n_hat = w / w_norm  # Normal vector (points toward the geometric positive class)
    t_hat = np.array([-n_hat[1], n_hat[0]])  # Tangential direction orthogonal to the normal

    # Data span determines how far we sample along the hyperplane
    xmin, ymin = X.min(axis=0) - 0.5
    xmax, ymax = X.max(axis=0) + 0.5
    box_corners = np.array([[xmin, ymin], [xmax, ymax]])
    diag = np.linalg.norm(box_corners[1] - box_corners[0])

    # Margin width (distance to either dashed line is 1 / ||w||)
    margin = 1.0 / w_norm
    max_offset = offset_ratio * margin

    intruders = []
    labels = []

    # Sample s values uniformly along the tangent to cover the visible region
    ss = np.linspace(-0.6 * diag, 0.6 * diag, num=max(3, k))
    rng.shuffle(ss)
    ss = ss[:k] if k > 0 else []

    # sgn = -label: place points on the geometric side opposite to their label
    sgn = -1 if label_of_intruders == 1 else 1

    for s in ss:
        # Offset from a point on the hyperplane along the normal direction
        d = rng.uniform(0.2 * max_offset, max_offset)
        base = x0 + s * t_hat
        p = base + sgn * d * n_hat

        # Add a small tangential jitter to avoid overlap
        p = p + rng.normal(scale=0.05 * margin, size=2)
        intruders.append(p)
        labels.append(label_of_intruders)

    if k == 0:
        return X.copy(), y.copy()

    X_new = np.vstack([X, np.array(intruders)])
    y_new = np.concatenate([y, np.array(labels, dtype=int)])
    return X_new, y_new
