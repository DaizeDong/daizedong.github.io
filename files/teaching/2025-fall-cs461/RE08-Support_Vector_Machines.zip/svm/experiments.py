import matplotlib.pyplot as plt
import numpy as np
from sklearn.svm import SVC

from .data import add_margin_intruders
from .plotting import plot_decision_2d


def fit_svc(X, y, C=1.0, kernel="linear", gamma="scale", degree=3):
    clf = SVC(C=C, kernel=kernel, gamma=gamma, degree=degree)
    clf.fit(X, y)
    return clf


def grid_plot_linear_with_intruders(X, y, Cs, k_intruders_list, seed=123, figsize=(3.2, 2.8), save_path=None):
    """
    Rows: varying counts of intruder points; columns: different C values.
    Each subplot refits a linear-kernel SVM and draws the resulting decision boundary.
    """
    n_rows = len(k_intruders_list)
    n_cols = len(Cs)
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(figsize[0] * n_cols, figsize[1] * n_rows))

    if n_rows == 1:
        axes = np.array([axes])
    if n_cols == 1:
        axes = axes.reshape(n_rows, 1)

    for i, k in enumerate(k_intruders_list):
        Xk, yk = add_margin_intruders(X, y, k=k, label_of_intruders=1, offset_ratio=0.6, seed=seed + i)
        for j, C in enumerate(Cs):
            ax = axes[i, j]
            clf = fit_svc(Xk, yk, C=C, kernel="linear")
            title = f"k={k} intruders  |  C={C:g}"
            plot_decision_2d(ax, clf, Xk, yk, C=C, title=title)

    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=160, bbox_inches="tight")
    return fig


def kernel_grid(X, y, Cs, gammas, kernel="rbf", degree=3, figsize=(3.2, 2.8), save_path=None):
    """
    Visualize how kernel SVM behavior changes across the C × gamma (or degree) grid.
    For RBF: rows = gamma, columns = C; for poly: rows = degree, columns = C.
    """
    if kernel == "rbf":
        n_rows = len(gammas)
        n_cols = len(Cs)
        fig, axes = plt.subplots(n_rows, n_cols, figsize=(figsize[0] * n_cols, figsize[1] * n_rows))
        for i, g in enumerate(gammas):
            for j, C in enumerate(Cs):
                ax = axes[i, j] if n_rows > 1 else axes[j]
                clf = fit_svc(X, y, C=C, kernel="rbf", gamma=g)
                title = f"RBF  |  C={C:g}, γ={g:g}"
                plot_decision_2d(ax, clf, X, y, C=C, title=title)
    elif kernel == "poly":
        n_rows = len(gammas) if gammas else 1
        n_cols = len(Cs)
        fig, axes = plt.subplots(n_rows, n_cols, figsize=(figsize[0] * n_cols, figsize[1] * n_rows))
        gammas = gammas or ["scale"]
        for i, g in enumerate(gammas):
            for j, C in enumerate(Cs):
                ax = axes[i, j] if n_rows > 1 else axes[j]
                clf = fit_svc(X, y, C=C, kernel="poly", gamma=g, degree=degree)
                title = f"Poly(d={degree})  |  C={C:g}, γ={g}"
                plot_decision_2d(ax, clf, X, y, C=C, title=title)
    else:
        raise ValueError("kernel must be 'rbf' or 'poly'")

    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=160, bbox_inches="tight")
    return fig
