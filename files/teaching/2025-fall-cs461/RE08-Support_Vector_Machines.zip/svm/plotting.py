import numpy as np
from joblib import Parallel, delayed
from matplotlib.colors import ListedColormap

CMAP_BG = ListedColormap(["#ddeeff", "#ffe9d6"])
CMAP_PT = ListedColormap(["#1f77b4", "#ff7f0e"])


def compute_alphas_full(clf, n_samples):
    """
    Extract each sample's alpha from sklearn's SVC (zero for non-support vectors).
    For binary classification: clf.dual_coef_ has shape (1, n_SV) with entries y_i * alpha_i.
    """
    alphas = np.zeros(n_samples, dtype=float)
    sv_idx = clf.support_
    dual = np.abs(clf.dual_coef_.ravel())
    alphas[sv_idx] = dual
    return alphas


def margin_violations(clf, X, y):
    """
    Compute hinge slack: xi_i = max(0, 1 - y_i * f(x_i)).
    xi > 0 means the point lies inside the margin or is misclassified; xi > 1 guarantees misclassification.
    """
    f = clf.decision_function(X)
    margins = y * f
    xi = np.maximum(0.0, 1.0 - margins)
    miscls = xi > 1.0 - 1e-12
    return xi, miscls


def plot_decision_2d(ax, clf, X, y, C, title=None, draw_bg=True, grid_resolution=400, n_jobs=-1):
    """
    Plot the 2D decision boundary plus margins (contours at -1, 0, +1) and support vectors.
    - Highlight support vectors with a black edge.
    - Emphasize near-boundary support vectors (alpha ≈ C) with a brighter outline.
    - Mark points inside the margin or misclassified with an x.
    
    Parameters:
    -----------
    grid_resolution : int
        Resolution of the decision boundary grid (default: 400, lower values are faster)
    n_jobs : int
        Number of parallel jobs for decision function computation (-1 for all cores)
    """
    # Background grid
    x_min, y_min = X.min(axis=0) - 1.0
    x_max, y_max = X.max(axis=0) + 1.0
    xx, yy = np.meshgrid(
        np.linspace(x_min, x_max, grid_resolution),
        np.linspace(y_min, y_max, grid_resolution),
    )
    grid_points = np.c_[xx.ravel(), yy.ravel()]

    # Parallelize decision_function computation (only use parallel for large grids)
    n_samples = len(grid_points)
    if n_jobs != 1 and n_samples > 5000:
        # Batch parallel computation for better performance
        batch_size = max(1000, n_samples // (abs(n_jobs) if n_jobs != -1 else 4))

        def compute_batch(start_idx):
            end_idx = min(start_idx + batch_size, n_samples)
            return clf.decision_function(grid_points[start_idx:end_idx])

        batches = list(range(0, n_samples, batch_size))
        results = Parallel(n_jobs=n_jobs, backend='threading')(delayed(compute_batch)(i) for i in batches)
        Z_flat = np.concatenate(results)
    else:
        Z_flat = clf.decision_function(grid_points)

    Z = Z_flat.reshape(xx.shape)

    if draw_bg:
        ax.contourf(xx, yy, (Z > 0).astype(int), alpha=0.15, cmap=CMAP_BG)

    # Decision boundary and margin contours
    cs = ax.contour(xx, yy, Z, levels=[-1, 0, 1], linestyles=["--", "-", "--"], linewidths=[1.2, 2.0, 1.2], colors="k")

    # Support vectors and alpha ≈ C - compute first
    alphas = compute_alphas_full(clf, n_samples=len(X))
    sv_mask = np.zeros(len(X), dtype=bool)
    sv_mask[clf.support_] = True
    at_bound = np.isclose(alphas, C, rtol=1e-2, atol=1e-3)

    # Training samples - exclude support vectors to avoid overlap
    pos_mask = (y == 1)
    neg_mask = (y == -1)
    pos_non_sv = pos_mask & ~sv_mask
    neg_non_sv = neg_mask & ~sv_mask
    
    if np.any(pos_non_sv):
        ax.scatter(X[pos_non_sv, 0], X[pos_non_sv, 1], c="#ff7f0e", s=35, edgecolors="none", alpha=0.9)
    if np.any(neg_non_sv):
        ax.scatter(X[neg_non_sv, 0], X[neg_non_sv, 1], c="#1f77b4", s=35, edgecolors="none", alpha=0.9)

    # Draw support vectors with their class colors and black edge
    pos_sv = pos_mask & sv_mask
    neg_sv = neg_mask & sv_mask
    
    if np.any(pos_sv):
        ax.scatter(X[pos_sv, 0], X[pos_sv, 1], c="#ff7f0e", s=35, edgecolors="k", linewidths=1.5, alpha=0.9)
    if np.any(neg_sv):
        ax.scatter(X[neg_sv, 0], X[neg_sv, 1], c="#1f77b4", s=35, edgecolors="k", linewidths=1.5, alpha=0.9)
    
    # Label for support vectors (only add once)
    if np.any(sv_mask):
        ax.scatter([], [], s=120, facecolors="none", edgecolors="k", linewidths=1.5, label="Support Vector")

    # Draw an extra ring around support vectors that are roughly on the margin (alpha ≈ C)
    if np.any(at_bound & sv_mask):
        ax.scatter(X[at_bound & sv_mask, 0], X[at_bound & sv_mask, 1],
                   s=120, facecolors="none", edgecolors="#d81b60", linewidths=2.0, label="Support Vector (α≈C)")

    # Flag margin violations and misclassifications
    # Only draw X markers for violations that are not already support vectors (to avoid overlap)
    xi, mis = margin_violations(clf, X, y)
    viol = xi > 1e-12
    viol_non_sv = viol & ~sv_mask  # Only mark violations that are not support vectors
    if np.any(viol_non_sv):
        ax.scatter(X[viol_non_sv, 0], X[viol_non_sv, 1], marker="x", c="k", s=55, linewidths=1.5, alpha=0.9, label="Margin Violation")

    # On-plot text summary
    txt = f"SV: {sv_mask.sum()} | viol: {viol.sum()} | mis: {mis.sum()}"
    ax.text(0.02, 0.98, txt, transform=ax.transAxes, va="top", ha="left",
            fontsize=12, bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="0.7", alpha=0.8))

    if title:
        ax.set_title(title, fontsize=14)
    ax.set_xlim(x_min, x_max)
    ax.set_ylim(y_min, y_max)
    ax.set_xticks([])
    ax.set_yticks([])
    return cs
