"""
Static comparison of different C values and noise point counts on linearly separable data.
Demonstrates how large C values and noise points can cause instability and non-convergence.
"""
import argparse
import os

import matplotlib.pyplot as plt
import numpy as np
from sklearn.svm import SVC

from svm.data import make_linear_separable, _fit_reference_hyperplane, _point_on_hyperplane
from svm.plotting import plot_decision_2d


def add_noise_points_to_opposite_class(X, y, k=5, seed=42):
    """
    Add noise points to the opposite class region, near the boundary.
    The noise points will be placed in the wrong class region (crossing the boundary).
    
    Parameters:
    -----------
    X : array-like, shape (n_samples, 2)
        Base linearly separable data
    y : array-like, shape (n_samples,)
        Labels (-1 or +1)
    k : int
        Number of noise points to add
    seed : int
        Random seed
    
    Returns:
    --------
    X_new : array-like, shape (n_samples + k, 2)
        Data with noise points added
    y_new : array-like, shape (n_samples + k,)
        Labels with noise points (wrong labels)
    """
    rng = np.random.RandomState(seed)

    # Fit a reference hyperplane to find the boundary
    w, b = _fit_reference_hyperplane(X, y, C=1e6)
    w_norm = np.linalg.norm(w)
    if w_norm == 0:
        raise ValueError("Degenerate hyperplane: ||w|| == 0")

    # Reference point on the hyperplane
    x0 = _point_on_hyperplane(w, b)
    n_hat = w / w_norm  # Normal vector pointing toward positive class
    t_hat = np.array([-n_hat[1], n_hat[0]])  # Tangential direction

    # Find the center of the negative class (to place noise points)
    neg_mask = (y == -1)
    pos_mask = (y == 1)

    if neg_mask.sum() > 0 and pos_mask.sum() > 0:
        neg_center = X[neg_mask].mean(axis=0)
        pos_center = X[pos_mask].mean(axis=0)

        # Data span
        xmin, ymin = X.min(axis=0) - 0.5
        xmax, ymax = X.max(axis=0) + 0.5
        box_corners = np.array([[xmin, ymin], [xmax, ymax]])
        diag = np.linalg.norm(box_corners[1] - box_corners[0])

        # Margin width
        margin = 1.0 / w_norm

        noise_points = []
        noise_labels = []

        # Place points on the negative side (labeled as +1) and positive side (labeled as -1)
        # Half points in negative region with +1 label, half in positive region with -1 label
        k_pos_noise = k // 2  # Points labeled +1 in negative region
        k_neg_noise = k - k_pos_noise  # Points labeled -1 in positive region

        # Sample along the tangent
        ss = np.linspace(-0.5 * diag, 0.5 * diag, num=max(3, k))
        rng.shuffle(ss)

        # Add noise points labeled +1 in negative class region (near boundary)
        for i in range(k_pos_noise):
            s = ss[i] if i < len(ss) else rng.uniform(-0.5 * diag, 0.5 * diag)
            # Start from negative class center, move toward boundary
            direction_to_boundary = x0 - neg_center
            direction_to_boundary = direction_to_boundary / np.linalg.norm(direction_to_boundary) if np.linalg.norm(direction_to_boundary) > 0 else -n_hat

            # Place point in negative region but close to boundary
            # Distance from negative center to boundary
            dist_to_boundary = np.abs(np.dot(neg_center - x0, n_hat))
            # Place at 70-90% of the way from center to boundary
            frac = rng.uniform(0.7, 0.9)
            p = neg_center + frac * dist_to_boundary * direction_to_boundary

            # Add tangential offset
            p = p + s * t_hat * 0.3
            # Add small jitter
            p = p + rng.normal(scale=0.1 * margin, size=2)

            noise_points.append(p)
            noise_labels.append(1)  # Wrong label for negative region

        # Add noise points labeled -1 in positive class region (near boundary)
        for i in range(k_neg_noise):
            s = ss[k_pos_noise + i] if (k_pos_noise + i) < len(ss) else rng.uniform(-0.5 * diag, 0.5 * diag)
            # Start from positive class center, move toward boundary
            direction_to_boundary = x0 - pos_center
            direction_to_boundary = direction_to_boundary / np.linalg.norm(direction_to_boundary) if np.linalg.norm(direction_to_boundary) > 0 else n_hat

            # Place point in positive region but close to boundary
            dist_to_boundary = np.abs(np.dot(pos_center - x0, n_hat))
            frac = rng.uniform(0.7, 0.9)
            p = pos_center + frac * dist_to_boundary * direction_to_boundary

            # Add tangential offset
            p = p + s * t_hat * 0.3
            # Add small jitter
            p = p + rng.normal(scale=0.1 * margin, size=2)

            noise_points.append(p)
            noise_labels.append(-1)  # Wrong label for positive region

        if k > 0:
            X_new = np.vstack([X, np.array(noise_points)])
            y_new = np.concatenate([y, np.array(noise_labels, dtype=int)])
        else:
            X_new = X.copy()
            y_new = y.copy()

        return X_new, y_new
    else:
        return X.copy(), y.copy()


def parse_args():
    p = argparse.ArgumentParser(
        description="Compare different C values and noise point counts on linearly separable data."
    )
    p.add_argument(
        "--n-per-class",
        type=int,
        default=25,
        help="Number of clean samples drawn for each class.",
    )
    p.add_argument(
        "--gap",
        type=float,
        default=3.5,
        help="Horizontal separation between the two classes in the clean dataset.",
    )
    p.add_argument(
        "--spread",
        type=float,
        default=1.0,
        help="Standard deviation (spread) of the Gaussian blobs used for each class.",
    )
    p.add_argument(
        "--seed",
        type=int,
        default=233,
        help="Random seed for reproducibility.",
    )
    p.add_argument(
        "--Cs",
        type=float,
        nargs="+",
        default=[1.0, 10.0, 100.0, 1000.0, 10000.0],
        help="List of C values to sweep over when training the SVM.",
    )
    p.add_argument(
        "--noise-counts",
        type=int,
        nargs="+",
        default=[0, 10, 20, 30],
        help="List of noise point counts for each row in the grid.",
    )
    p.add_argument(
        "--save-path",
        type=str,
        default=None,
        help="If set, the figure is saved to this path instead of being shown interactively.",
    )
    p.add_argument(
        "--dpi",
        type=int,
        default=320,
        help="DPI for saved figure.",
    )
    return p.parse_args()


def main():
    args = parse_args()

    # Generate linearly separable base data
    X_base, y_base = make_linear_separable(
        n_per_class=args.n_per_class,
        gap=args.gap,
        spread=args.spread,
        seed=args.seed
    )

    # Test different C values and noise point counts
    Cs = args.Cs
    noise_counts = args.noise_counts

    n_rows = len(noise_counts)
    n_cols = len(Cs)

    # Increase font sizes
    plt.rcParams['font.size'] = 10
    plt.rcParams['axes.titlesize'] = 11

    fig, axes = plt.subplots(n_rows, n_cols, figsize=(3.5 * n_cols, 3.0 * n_rows))

    if n_rows == 1:
        axes = np.array([axes])
    if n_cols == 1:
        axes = axes.reshape(n_rows, 1)

    for i, n_noise in enumerate(noise_counts):
        # Generate dataset with noise points
        X_noise, y_noise = add_noise_points_to_opposite_class(
            X_base, y_base, k=n_noise, seed=args.seed
        )

        for j, C in enumerate(Cs):
            ax = axes[i, j]

            # Fit with different C values
            clf = SVC(C=C, kernel="linear", max_iter=10000)
            clf.fit(X_noise, y_noise)

            # Check convergence
            converged = clf.n_iter_ < clf.max_iter
            if not converged:
                status = "NOT CONVERGED"
                title_color = "red"
            else:
                status = "Converged"
                title_color = "black"

            # Plot
            plot_decision_2d(
                ax,
                clf,
                X_noise,
                y_noise,
                C=C,
                title=f"C={C:.2g}\nNoise: {n_noise}\n{status}",
                n_jobs=-1,
            )

            # Update title color
            ax.title.set_color(title_color)

            # Add warning if not converged
            if not converged:
                ax.text(0.5, 0.02, "Unstable!",
                        transform=ax.transAxes, ha="center", va="bottom",
                        fontsize=9, bbox=dict(boxstyle="round,pad=0.3", fc="yellow", ec="red", alpha=0.8))

    plt.tight_layout()

    if args.save_path:
        # Create directory if it doesn't exist
        save_dir = os.path.dirname(args.save_path)
        if save_dir and not os.path.exists(save_dir):
            os.makedirs(save_dir, exist_ok=True)

        fig.savefig(args.save_path, dpi=args.dpi, bbox_inches="tight")
        print(f"[saved] {args.save_path}")
    else:
        plt.show()


if __name__ == "__main__":
    main()
