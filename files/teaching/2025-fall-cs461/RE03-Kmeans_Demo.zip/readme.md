# K-Means Demo

This project provides a step-by-step visualization of the K-Means clustering algorithm. It generates both multi-page PDFs and animated GIFs that show how cluster centers move, how data points are reassigned, and how metrics (inertia and accuracy) evolve during iterations.



## Installation
**Requirement:** Python 3.9+

```bash
pip install -r requirements.txt
```



## Run

Execute the script to generate multi-page PDFs and animated GIFs (stored in `./results`):

```bash
python kmeans.py
```

After running, you’ll see console logs for each iteration (`iter / inertia / counts / centroids`) and output files:

```
results/
  gaussians/ gaussians_kmeans_steps.pdf  gaussians_kmeans_steps.gif
  circles/   circles_kmeans_steps.pdf    circles_kmeans_steps.gif
  moons/     moons_kmeans_steps.pdf      moons_kmeans_steps.gif
  blobs/     blobs_kmeans_steps.pdf      blobs_kmeans_steps.gif
```



## What to Look At

- **Left panel**: data points + decision regions + cluster centers (stars). Movement of centers is shown with lines and arrows.
- **Right panel**: metric curves — **Inertia** (left axis, lower is better) and, if labels are given, **Accuracy** (right axis, higher is better).



## Minimal Customization

Edit `main()` and adjust:

```python
run_kmeans_and_export(
    X,                 # your dataset (N,2)
    k=4,               # number of clusters
    out_prefix="exp1", # output subfolder
    init="k-means++",  # initialization: 'k-means++' or 'random'
    max_iter=20,
    tol=1e-4,
    gif_fps=1.25,
    random_state=42,   # seed for reproducibility
    y_true=y,          # provide labels for accuracy, or None
)
```

Built-in dataset generator:

```python
X, y = generate_dataset("gaussians", n=1000, random_state=233, means=[...], covs=[...], sizes=[...])
# Options: "gaussians", "circles" (factor, noise), "moons" (noise), "blobs" (centers, cluster_std)
```



## Notes

- **PDF GIFs don’t animate**: open `.gif` in an image viewer or embed in slides.
- **GIF too large**: reduce `gif_fps` or `max_iter`.

