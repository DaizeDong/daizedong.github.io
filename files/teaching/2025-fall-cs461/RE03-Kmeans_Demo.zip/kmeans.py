import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
from sklearn import datasets
from matplotlib.backends.backend_pdf import PdfPages
from PIL import Image
from pathlib import Path
from itertools import permutations


# ---------------------------
# 1) DATASETS
# ---------------------------
def generate_dataset(kind="gaussians", n=1000, random_state=233, **kwargs):
    """
    Build simple 2D toy datasets for clustering demos.
    Returns (X, y) where y are ground-truth cluster ids if available.

    kind:
      - "gaussians": 2D Gaussian blobs (customizable via means, covs, sizes)
      - "circles": concentric circles from sklearn.make_circles (factor, noise)
      - "moons": two interleaving half-moons from sklearn.make_moons (noise)
      - "blobs": generic blobs from sklearn.make_blobs (centers, cluster_std)
    """
    rng = np.random.RandomState(random_state)

    if kind == "gaussians":
        means = kwargs.get("means", [(5, 5), (15, 15), (17, 3), (2, 16)])
        covs = kwargs.get(
            "covs",
            [([4, 0], [0, 4]), ([9, 0], [0, 9]), ([1, 0], [0, 1]), ([1, 0], [0, 1])],
        )
        sizes = kwargs.get("sizes", [n, n, n, n])
        parts, labels = [], []
        for idx, (m, S, s) in enumerate(zip(means, covs, sizes)):
            pts = rng.multivariate_normal(
                np.array(m, dtype=float), np.array(S, dtype=float), int(s)
            )
            parts.append(pts)
            labels.append(np.full(len(pts), idx, dtype=int))
        X = np.concatenate(parts, axis=0)
        y = np.concatenate(labels, axis=0)

    elif kind == "circles":
        factor = kwargs.get("factor", 0.5)
        noise = kwargs.get("noise", 0.05)
        X, y = datasets.make_circles(
            n_samples=n, factor=factor, noise=noise, random_state=random_state
        )

    elif kind == "moons":
        noise = kwargs.get("noise", 0.08)
        X, y = datasets.make_moons(
            n_samples=n, noise=noise, random_state=random_state
        )

    elif kind == "blobs":
        centers = kwargs.get("centers", [(0, 0), (5, 5), (-5, 5)])
        std = kwargs.get("cluster_std", 1.2)
        X, y = datasets.make_blobs(
            n_samples=n,
            centers=np.array(centers, dtype=float),
            cluster_std=std,
            random_state=random_state,
        )
    else:
        raise ValueError(f"Unknown kind={kind}")

    return X.astype(float), y.astype(int)


# ---------------------------
# 2) KMEANS
# ---------------------------
def _kmeans_plusplus_init(X, n_clusters, rng):
    """Minimal k-means++ initializer."""
    n_samples, n_features = X.shape
    centers = np.empty((n_clusters, n_features), dtype=X.dtype)
    first = rng.randint(n_samples)
    centers[0] = X[first]

    closest_sq = np.sum((X - centers[0]) ** 2, axis=1)
    for c in range(1, n_clusters):
        probs = closest_sq / closest_sq.sum()
        idx = rng.choice(n_samples, p=probs)
        centers[c] = X[idx]
        new_sq = np.sum((X - centers[c]) ** 2, axis=1)
        closest_sq = np.minimum(closest_sq, new_sq)
    return centers


def kmeans_stepwise(
    X, n_clusters, init="k-means++", random_state=0, max_iter=100, tol=1e-4
):
    """
    Run K-Means while recording per-iteration snapshots (centroids, labels, inertia).
    """
    rng = np.random.RandomState(random_state)
    if init == "random":
        centroids = X[rng.choice(len(X), n_clusters, replace=False)].copy()
    elif init == "k-means++":
        centroids = _kmeans_plusplus_init(X, n_clusters, rng)
    else:
        raise ValueError("init must be 'random' or 'k-means++'.")

    steps = []
    for it in range(max_iter):
        d2 = np.sum((X[:, None, :] - centroids[None, :, :]) ** 2, axis=2)
        labels = np.argmin(d2, axis=1)
        inertia = float(d2[np.arange(len(X)), labels].sum())
        steps.append(
            {"iter": it, "centroids": centroids.copy(), "labels": labels.copy(), "inertia": inertia}
        )

        new_centroids = centroids.copy()
        for j in range(n_clusters):
            mask = labels == j
            if np.any(mask):
                new_centroids[j] = X[mask].mean(axis=0)
            else:
                far_idx = np.argmax(d2.min(axis=1))
                new_centroids[j] = X[far_idx]

        if np.linalg.norm(new_centroids - centroids) <= tol:
            centroids = new_centroids
            break
        centroids = new_centroids

    d2 = np.sum((X[:, None, :] - centroids[None, :, :]) ** 2, axis=2)
    labels = np.argmin(d2, axis=1)
    inertia = float(d2[np.arange(len(X)), labels].sum())
    steps.append(
        {
            "iter": steps[-1]["iter"] + 1 if steps else 0,
            "centroids": centroids.copy(),
            "labels": labels.copy(),
            "inertia": inertia,
        }
    )
    return steps


# ---------------------------
# 3) METRICS
# ---------------------------
def clustering_accuracy(y_true, y_pred, k):
    """Best-permutation clustering accuracy; returns np.nan if y_true is None."""
    if y_true is None:
        return np.nan
    best = 0.0
    classes = list(range(k))
    for perm in permutations(classes, k):
        mapped = np.array([perm[c] if c < k else c for c in y_pred])
        acc = (mapped == y_true).mean()
        if acc > best:
            best = acc
    return float(best)


# ---------------------------
# 4) PLOTTING / RENDERING
# ---------------------------
class KMeansAnimator:
    """
    Compact, reusable renderer for:
      - cluster view with decision regions
      - metric panel (inertia + optional accuracy)
    Designed to avoid tiny utility functions and to reduce duplication.
    """

    def __init__(self, X, title, y_true=None, dpi=240, figsize=(10, 6)):
        self.X = X
        self.title = title
        self.y_true = y_true
        self.have_labels = y_true is not None
        self.dpi = dpi
        self.figsize = figsize

        self.inertia_hist = []
        self.acc_hist = []
        self.prev_centroids = None

    def _decision_regions(self, ax, centroids, resolution=280, alpha=0.18):
        x_min, x_max = self.X[:, 0].min(), self.X[:, 0].max()
        y_min, y_max = self.X[:, 1].min(), self.X[:, 1].max()
        pad_x = 0.05 * (x_max - x_min + 1e-9)
        pad_y = 0.05 * (y_max - y_min + 1e-9)

        xx, yy = np.meshgrid(
            np.linspace(x_min - pad_x, x_max + pad_x, resolution),
            np.linspace(y_min - pad_y, y_max + pad_y, resolution),
        )
        grid = np.c_[xx.ravel(), yy.ravel()]
        d2 = np.sum((grid[:, None, :] - centroids[None, :, :]) ** 2, axis=2)
        Z = np.argmin(d2, axis=1).reshape(xx.shape)

        ax.contourf(
            xx,
            yy,
            Z,
            levels=np.arange(centroids.shape[0] + 1) - 0.5,
            cmap="tab10",
            alpha=alpha,
            antialiased=True,
        )
        ax.contour(
            xx,
            yy,
            Z,
            levels=np.arange(centroids.shape[0] + 1) - 0.5,
            colors="k",
            linewidths=0.6,
            alpha=0.5,
        )

    def _cluster_panel(self, ax, centroids=None, labels=None, title=""):
        ax.set_title(title, fontsize=11)
        ax.grid(alpha=0.25)

        x_min, x_max = self.X[:, 0].min(), self.X[:, 0].max()
        y_min, y_max = self.X[:, 1].min(), self.X[:, 1].max()
        pad_x = 0.05 * (x_max - x_min + 1e-9)
        pad_y = 0.05 * (y_max - y_min + 1e-9)
        ax.set_xlim(x_min - pad_x, x_max + pad_x)
        ax.set_ylim(y_min - pad_y, y_max + pad_y)
        ax.set_box_aspect(1)

        if centroids is not None:
            self._decision_regions(ax, centroids, resolution=280, alpha=0.18)

        if labels is not None and centroids is not None:
            cmap = plt.get_cmap("tab10")
            k = centroids.shape[0]
            for j in range(k):
                pts = self.X[labels == j]
                if len(pts):
                    ax.scatter(
                        pts[:, 0],
                        pts[:, 1],
                        s=6,
                        lw=0,
                        color=cmap(j % 10),
                        label=f"C{j}",
                    )
            ax.legend(loc="best", fontsize=7, frameon=True, fancybox=True, framealpha=0.9)
        else:
            ax.scatter(self.X[:, 0], self.X[:, 1], s=6, lw=0, color="gray")

        if centroids is not None:
            ax.scatter(
                centroids[:, 0],
                centroids[:, 1],
                s=120,
                marker="*",
                edgecolor="black",
                linewidths=1.0,
                zorder=5,
            )

    def _setup_metric_axes(self, axR_needed: bool):
        axL = plt.gca()
        axL.set_title("Inertia / Accuracy", fontsize=12)
        axL.set_xlabel("Step", fontsize=11)
        axL.set_ylabel("Inertia", fontsize=11)
        axL.grid(alpha=0.35)
        axL.tick_params(labelsize=10)
        axR = None
        if axR_needed:
            axR = axL.twinx()
            axR.set_ylabel("Accuracy (%)", fontsize=11)
            axR.set_ylim(0, 110)
            axR.tick_params(labelsize=10)
        return axL, axR

    @staticmethod
    def _clamp_to_ylim(ax, x, y, frac_pad=0.02):
        ymin, ymax = ax.get_ylim()
        pad = (ymax - ymin) * frac_pad
        return x, min(max(y, ymin + pad), ymax - pad)

    @staticmethod
    def _subsample_indices(n, max_labels=12):
        if n <= max_labels:
            return list(range(n))
        stride = int(np.ceil(n / max_labels))
        return list(range(0, n, stride))

    def frame_initial_raw(self):
        fig, axes = plt.subplots(1, 2, figsize=self.figsize, dpi=self.dpi)
        plt.suptitle(f"{self.title} — initial data (unclustered)", fontsize=12)

        self._cluster_panel(axes[0], centroids=None, labels=None, title="Initial data")
        plt.sca(axes[1])
        self._setup_metric_axes(self.have_labels)

        for ax in axes:
            ax.set_box_aspect(1)
            ax.tick_params(labelsize=10)

        fig.tight_layout(rect=[0, 0, 1, 0.92])
        fig.canvas.draw()
        rgba = np.asarray(fig.canvas.buffer_rgba())
        plt.close(fig)
        return rgba[..., :3].copy()

    def frame_initial_centers(self, centroids):
        fig, axes = plt.subplots(1, 2, figsize=self.figsize, dpi=self.dpi)
        plt.suptitle(f"{self.title} — initial centers (no labels)", fontsize=12)

        self._cluster_panel(axes[0], centroids=centroids, labels=None, title="Initial centers")
        plt.sca(axes[1])
        self._setup_metric_axes(self.have_labels)

        for ax in axes:
            ax.set_box_aspect(1)
            ax.tick_params(labelsize=10)

        self.prev_centroids = centroids.copy()

        fig.tight_layout(rect=[0, 0, 1, 0.92])
        fig.canvas.draw()
        rgba = np.asarray(fig.canvas.buffer_rgba())
        plt.close(fig)
        return rgba[..., :3].copy()

    def frame_step(self, step, y_true=None):
        labels = step["labels"]
        C = step["centroids"]
        k = C.shape[0]

        self.inertia_hist.append(step["inertia"])

        acc_val = clustering_accuracy(y_true, labels, k) if self.have_labels else np.nan
        if self.have_labels:
            self.acc_hist.append(acc_val)

        fig, axes = plt.subplots(1, 2, figsize=self.figsize, dpi=self.dpi)
        sup = f"{self.title} — iter {step['iter']}  |  inertia={step['inertia']:.1f}"
        if self.have_labels:
            sup += f"  |  accuracy={acc_val * 100:.1f}%"
        plt.suptitle(sup, fontsize=12)

        # Left: clusters
        self._cluster_panel(axes[0], centroids=C, labels=labels, title="Cluster assignments")
        axes[0].tick_params(labelsize=10)

        # draw centroid movement lines/arrows from previous step
        if self.prev_centroids is not None and self.prev_centroids.shape == C.shape:
            cmap = plt.get_cmap("tab10")
            for j in range(k):
                x0, y0 = self.prev_centroids[j]
                x1, y1 = C[j]
                # line path
                axes[0].plot([x0, x1], [y0, y1], linewidth=1.4, color="black", alpha=0.85)
                # arrow head pointing to new position
                axes[0].annotate("", xy=(x1, y1), xytext=(x0, y0),
                                 arrowprops=dict(arrowstyle="-|>", lw=1.2, color="black", alpha=0.9))

        # update prev for next frame
        self.prev_centroids = C.copy()

        # Right: metrics
        plt.sca(axes[1])
        axL, axR = self._setup_metric_axes(self.have_labels)

        xs_inertia = range(len(self.inertia_hist))
        lineL, = axL.plot(xs_inertia, self.inertia_hist, marker="o", linewidth=1.8, label="Inertia", color="tab:blue")

        # annotate inertia (subsample)
        for j in self._subsample_indices(len(self.inertia_hist), max_labels=12):
            yv = self.inertia_hist[j]
            dy = 6 if (j % 2 == 0) else -10
            axL.annotate(f"{yv:.1f}", (j, yv), textcoords="offset points", xytext=(3, dy),
                         fontsize=8, clip_on=True)

        lines, labels_ = [lineL], ["Inertia"]

        if self.have_labels:
            xs_acc = range(len(self.acc_hist))
            acc_pct = np.array(self.acc_hist) * 100.0
            lineR, = axR.plot(xs_acc, acc_pct, marker="o", linewidth=1.8, linestyle="--", label="Accuracy (%)", color="tab:orange")

            # annotate accuracy
            for j in self._subsample_indices(len(acc_pct), max_labels=12):
                ap = acc_pct[j]
                xi, yi = self._clamp_to_ylim(axR, j, ap, frac_pad=0.02)
                dy = 6 if (j % 2 == 0) else -10
                axR.annotate(f"{ap:.1f}%", (xi, yi), textcoords="offset points", xytext=(3, dy),
                             fontsize=8, clip_on=True)

            lines += [lineR]
            labels_ += ["Accuracy (%)"]

        axes[1].legend(lines, labels_, loc="lower left", fontsize=9)

        for ax in axes:
            ax.set_box_aspect(1)
            ax.tick_params(labelsize=10)

        fig.tight_layout(rect=[0, 0, 1, 0.92])
        fig.canvas.draw()
        rgba = np.asarray(fig.canvas.buffer_rgba())
        plt.close(fig)
        return rgba[..., :3].copy()


# ---------------------------
# 5) EXPORTS
# ---------------------------
def export_pdf_and_gif(frames, pdf_path, gif_path, gif_fps=1.25):
    """
    Save frames as a multi-page PDF and an animated GIF.
    """
    pdf_path = Path(pdf_path)
    gif_path = Path(gif_path)
    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    gif_path.parent.mkdir(parents=True, exist_ok=True)

    with PdfPages(pdf_path) as pdf:
        for frame in frames:
            h, w, _ = frame.shape
            fig = plt.figure(figsize=(w / 100, h / 100), dpi=240)
            plt.axis("off")
            plt.imshow(frame)
            pdf.savefig(fig, bbox_inches="tight", pad_inches=0)
            plt.close(fig)
    print(f"[OK] Saved PDF: {pdf_path}")

    pil_frames = [Image.fromarray(frame) for frame in frames]
    if len(pil_frames) == 1:
        pil_frames[0].save(gif_path, format="GIF")
    else:
        duration_ms = int(1000 / gif_fps)
        pil_frames[0].save(
            gif_path,
            save_all=True,
            append_images=pil_frames[1:],
            duration=duration_ms,
            loop=0,
            disposal=2,
            optimize=False,
        )
    print(f"[OK] Saved GIF: {gif_path}")


# ---------------------------
# 6) HIGH-LEVEL DRIVER
# ---------------------------
def _centroids_str(arr):
    s = np.array2string(arr, precision=3, suppress_small=True, separator=", ")
    return " ".join(s.split())


def run_kmeans_and_export(
    X,
    k,
    out_prefix,
    results_dir="results",
    title=None,
    init="k-means++",
    max_iter=20,
    tol=1e-4,
    gif_fps=1.25,
    random_state=0,
    y_true=None,
):
    """
    High-level helper:
      1) run k-means (recording snapshots),
      2) print per-iteration summaries,
      3) render frames (clusters + inertia + accuracy),
      4) export PDF and GIF.
    Artifacts are placed under {results_dir}/{out_prefix}/.
    """
    Path(results_dir).mkdir(exist_ok=True, parents=True)
    title = title or f"K-Means (k={k})"

    steps = kmeans_stepwise(
        X, n_clusters=k, init=init, random_state=random_state, max_iter=max_iter, tol=tol
    )

    print(f"\n{out_prefix} — per-iteration snapshots:")
    for s in steps:
        counts = np.bincount(s["labels"], minlength=k).tolist()
        c_str = _centroids_str(s["centroids"])
        print(f"iter {s['iter']:>2} | inertia={s['inertia']:.2f} | counts={counts} | centroids={c_str}")

    animator = KMeansAnimator(X, title=f"{out_prefix} — {title}", y_true=y_true, dpi=240, figsize=(10, 6))

    frames = []
    frames.append(animator.frame_initial_raw())
    frames.append(animator.frame_initial_centers(steps[0]["centroids"]))
    for s in steps:
        frames.append(animator.frame_step(s, y_true=y_true))

    pdf_path = Path(results_dir) / out_prefix / f"{out_prefix}_kmeans_steps.pdf"
    gif_path = Path(results_dir) / out_prefix / f"{out_prefix}_kmeans_steps.gif"
    export_pdf_and_gif(frames, pdf_path=pdf_path, gif_path=gif_path, gif_fps=gif_fps)

    return {"steps": steps, "pdf": str(pdf_path), "gif": str(gif_path)}


def main():
    # Example 1: four Gaussians
    X1, y1 = generate_dataset(
        "gaussians",
        n=1000,
        random_state=233,
        means=[(5, 5), (15, 15), (17, 3), (2, 16)],
        covs=[([4, 0], [0, 4]), ([9, 0], [0, 9]), ([1, 0], [0, 1]), ([1, 0], [0, 1])],
        sizes=[1000, 1000, 1000, 1000],
    )
    run_kmeans_and_export(
        X1,
        k=4,
        out_prefix="gaussians",
        results_dir="results",
        init="k-means++",
        max_iter=20,
        tol=1e-4,
        gif_fps=1.25,
        random_state=23,
        y_true=y1,
    )

    # Example 2: circles
    X2, y2 = generate_dataset("circles", n=1000, random_state=0, factor=0.5, noise=0.05)
    run_kmeans_and_export(
        X2,
        k=2,
        out_prefix="circles",
        results_dir="results",
        init="k-means++",
        max_iter=20,
        tol=1e-4,
        gif_fps=1.25,
        random_state=0,
        y_true=y2,
    )

    # Example 3: moons
    X3, y3 = generate_dataset("moons", n=1000, random_state=42, noise=0.08)
    run_kmeans_and_export(
        X3,
        k=2,
        out_prefix="moons",
        results_dir="results",
        init="k-means++",
        max_iter=20,
        tol=1e-4,
        gif_fps=1.25,
        random_state=42,
        y_true=y3,
    )

    # Example 4: blobs
    X4, y4 = generate_dataset(
        "blobs",
        n=1200,
        random_state=7,
        centers=[(0, 0), (6, 6), (-6, 6)],
        cluster_std=1.2,
    )
    run_kmeans_and_export(
        X4,
        k=3,
        out_prefix="blobs",
        results_dir="results",
        init="k-means++",
        max_iter=20,
        tol=1e-4,
        gif_fps=1.25,
        random_state=7,
        y_true=y4,
    )

    print("\n[Done] All artifacts are in ./results")


if __name__ == "__main__":
    main()
