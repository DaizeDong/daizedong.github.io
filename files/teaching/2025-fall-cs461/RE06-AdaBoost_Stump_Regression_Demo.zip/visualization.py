# visualization.py
"""
AdaBoost visualization utilities.
Contains functions to render decision boundaries and export them as PDF/GIF.
"""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from matplotlib.backends.backend_pdf import PdfPages

# Unified plotting settings (shared by both visualization functions)
PLOT_SETTINGS = {
    'point_size': 140.0,           # marker area
    'edge_linewidth': 2.0,
    'cmap': 'RdYlBu_r',
    'contour_levels': 200,
    'alpha': 0.9,
    'rcParams': {'font.size': 14},
}


def sigmoid(x):
    """Sigmoid function with clipping for numerical stability."""
    return 1 / (1 + np.exp(-np.clip(x, -500, 500)))


def canvas_to_rgb_array(fig):
    """Convert a Matplotlib figure canvas to an RGB NumPy array."""
    fig.canvas.draw()
    rgba = np.asarray(fig.canvas.buffer_rgba())
    return rgba[..., :3].copy()


def export_pdf_and_gif(frames, pdf_path, gif_path, gif_fps=1.25):
    """Export a list of RGB frames to both a PDF (each frame as a page) and a GIF."""
    pdf_path = Path(pdf_path)
    gif_path = Path(gif_path)
    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    gif_path.parent.mkdir(parents=True, exist_ok=True)

    # PDF export
    with PdfPages(pdf_path) as pdf:
        for frame in frames:
            h, w, _ = frame.shape
            fig = plt.figure(figsize=(w / 100, h / 100), dpi=240)
            plt.axis("off")
            plt.imshow(frame)
            pdf.savefig(fig, bbox_inches="tight", pad_inches=0)
            plt.close(fig)
    print(f"[OK] Saved PDF: {pdf_path}")

    # GIF export
    pil_frames = [Image.fromarray(frame) for frame in frames]
    if len(pil_frames) == 1:
        pil_frames[0].save(gif_path, format="GIF")
    else:
        duration_ms = int(1000 / gif_fps)
        pil_frames[0].save(
            gif_path,
            save_all=True,
            append_images=pil_frames[1:],
            duration=duration_ms,
            loop=0,
            disposal=2,
            optimize=False,
        )
    print(f"[OK] Saved GIF: {gif_path}")


def _scatter_points_with_classification_status(ax, X, y, y_pred, colors_pts):
    """Scatter plot of samples, styling borders by classification correctness."""
    # Ensure y and y_pred are 1-D arrays with the same length for indexing
    y = np.asarray(y).ravel()
    y_pred = np.asarray(y_pred).ravel()

    if y_pred.shape != y.shape:
        if y_pred.size == 1:
            y_pred = np.full_like(y, y_pred.item())
        else:
            try:
                y_pred = np.broadcast_to(y_pred, y.shape)
            except Exception:
                raise ValueError(f"y and y_pred have incompatible shapes: {y.shape} vs {y_pred.shape}")

    n = y.shape[0]
    sizes = PLOT_SETTINGS['point_size']

    # Compute correctness mask
    correct_mask = np.asarray(y == y_pred).ravel()

    xs = X[0]
    ys = X[1]
    for i, is_correct in enumerate(correct_mask):
        if bool(is_correct):
            # Correctly classified: solid border
            ax.scatter(xs[i], ys[i],
                       c=colors_pts[i],
                       s=sizes,
                       edgecolors='black',
                       linewidth=PLOT_SETTINGS['edge_linewidth'],
                       alpha=PLOT_SETTINGS['alpha'])
        else:
            # Misclassified: dashed border
            ax.scatter(xs[i], ys[i],
                       c=colors_pts[i],
                       s=sizes,
                       edgecolors='black',
                       linewidth=PLOT_SETTINGS['edge_linewidth'],
                       linestyle='--',
                       alpha=PLOT_SETTINGS['alpha'])


def create_stump_decision_boundary_visualization(X, y, stumps, output_dir="output", output_name="adaboost_stump_decision_boundary"):
    """
    Decision boundary visualization for decision stumps.
    Left:  current weak learner boundary.
    Right: ensemble boundary up to the current learner.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(exist_ok=True)

    # 2D grid
    x_min, x_max = X[0].min() - 0.5, X[0].max() + 0.5
    y_min, y_max = X[1].min() - 0.5, X[1].max() + 0.5
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 300),
                         np.linspace(y_min, y_max, 300))
    grid_points = np.c_[xx.ravel(), yy.ravel()].T  # shape: (2, N)

    frames = []
    alphas = [stump.alpha for stump in stumps]
    cum_alpha = np.cumsum(alphas)

    for i in range(len(stumps)):
        # Right: ensemble decision boundary
        ensemble_votes = np.zeros(grid_points.shape[1], dtype=float)
        for j in range(i + 1):
            stump_j = stumps[j]
            feature = grid_points[stump_j.feature_index]
            preds = np.ones(feature.shape[0], dtype=int)
            if stump_j.polarity == 1:
                preds[feature < stump_j.threshold] = -1
            else:
                preds[feature >= stump_j.threshold] = -1
            ensemble_votes += stump_j.alpha * preds

        # Left: current weak learner
        stump_i = stumps[i]
        feature_i = grid_points[stump_i.feature_index]
        preds_i = np.ones(feature_i.shape[0], dtype=int)
        if stump_i.polarity == 1:
            preds_i[feature_i < stump_i.threshold] = -1
        else:
            preds_i[feature_i >= stump_i.threshold] = -1

        Z_ensemble = ensemble_votes.reshape(xx.shape)
        Z_current = preds_i.reshape(xx.shape)

        # Current learner's alpha normalized by cumulative alpha
        norm_w = stump_i.alpha / (cum_alpha[i] if cum_alpha[i] else 1.0)

        # Predictions on training data (for styling)
        current_stump_preds = np.ones(X.shape[1], dtype=int)
        if stump_i.polarity == 1:
            current_stump_preds[X[stump_i.feature_index] < stump_i.threshold] = -1
        else:
            current_stump_preds[X[stump_i.feature_index] >= stump_i.threshold] = -1
        current_stump_preds = (current_stump_preds + 1) // 2  # {-1,+1} -> {0,1}

        # Ensemble predictions on training data
        ensemble_votes_train = np.zeros(X.shape[1], dtype=float)
        for j in range(i + 1):
            stump_j = stumps[j]
            vals_train = X[stump_j.feature_index]
            preds_train = np.ones(X.shape[1], dtype=int)
            if stump_j.polarity == 1:
                preds_train[vals_train < stump_j.threshold] = -1
            else:
                preds_train[vals_train >= stump_j.threshold] = -1
            ensemble_votes_train += stump_j.alpha * preds_train

        ensemble_preds = np.where(ensemble_votes_train >= 0, 1, -1)
        ensemble_preds = (ensemble_preds + 1) // 2  # {-1,+1} -> {0,1}

        # Plot
        fig, (ax_l, ax_r) = plt.subplots(1, 2, figsize=(18, 8))
        plt.rcParams.update(PLOT_SETTINGS['rcParams'])

        colors_pts = ['red' if int(label) == 1 else 'blue' for label in y]

        # Left: current stump
        ax_l.tick_params(axis='both', which='major', labelsize=12)
        contour_l = ax_l.contourf(xx, yy, Z_current, levels=PLOT_SETTINGS['contour_levels'],
                                  alpha=PLOT_SETTINGS['alpha'], cmap=PLOT_SETTINGS['cmap'])
        ax_l.contour(xx, yy, Z_current, levels=[0], colors='black', linewidths=2)
        _scatter_points_with_classification_status(ax_l, X, y, current_stump_preds, colors_pts)
        ax_l.set_xlim(x_min, x_max)
        ax_l.set_ylim(y_min, y_max)
        ax_l.set_xlabel('X1', fontsize=16, fontweight='bold')
        ax_l.set_ylabel('X2', fontsize=16, fontweight='bold')
        ax_l.set_title(f'Current stump #{i + 1}\nalpha={stump_i.alpha:.3f}, normalized={norm_w:.3f}',
                       fontsize=16, fontweight='bold', pad=12)
        cbar_l = plt.colorbar(contour_l, ax=ax_l)
        cbar_l.set_label('Stump prediction', fontsize=14, fontweight='bold')

        # Right: ensemble boundary
        ax_r.tick_params(axis='both', which='major', labelsize=12)
        contour_r = ax_r.contourf(xx, yy, Z_ensemble, levels=PLOT_SETTINGS['contour_levels'],
                                  alpha=PLOT_SETTINGS['alpha'], cmap=PLOT_SETTINGS['cmap'])
        ax_r.contour(xx, yy, Z_ensemble, levels=[0], colors='black', linewidths=2)
        # Add the current stump's boundary as a dashed line for reference
        ax_r.contour(xx, yy, Z_current, levels=[0], colors='gray', linewidths=1, linestyles='--', alpha=0.7)
        _scatter_points_with_classification_status(ax_r, X, y, ensemble_preds, colors_pts)
        ax_r.set_xlim(x_min, x_max)
        ax_r.set_ylim(y_min, y_max)
        ax_r.set_xlabel('X1', fontsize=16, fontweight='bold')
        ax_r.set_ylabel('X2', fontsize=16, fontweight='bold')
        ax_r.set_title(f'Ensemble after {i + 1} stumps (α-weighted votes)',
                       fontsize=16, fontweight='bold', pad=12)
        cbar_r = plt.colorbar(contour_r, ax=ax_r)
        cbar_r.set_label('Ensemble votes', fontsize=14, fontweight='bold')

        frames.append(canvas_to_rgb_array(fig))
        plt.close(fig)

    export_pdf_and_gif(frames, output_dir / f"{output_name}.pdf",
                       output_dir / f"{output_name}.gif")

    return frames


def create_regression_decision_boundary_visualization(X, y, lines, output_dir="output", output_name="adaboost_regression_decision_boundary"):
    """
    Left:  current weak learner's sigmoid probability with 0.5 contour.
    Right: α-weighted hard-vote ensemble (piecewise boundary) with 0-level contour.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(exist_ok=True)

    # 2D grid
    x_min, x_max = X[0].min() - 0.5, X[0].max() + 0.5
    y_min, y_max = X[1].min() - 0.5, X[1].max() + 0.5
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 300),
                         np.linspace(y_min, y_max, 300))
    grid_points = np.c_[xx.ravel(), yy.ravel()].T  # shape: (2, N)

    frames = []
    alphas = [ln.alpha for ln in lines]
    cum_alpha = np.cumsum(alphas)

    for i in range(len(lines)):
        # Right: α-weighted hard-vote ensemble over the grid
        ensemble_votes = np.zeros(grid_points.shape[1], dtype=float)
        for j in range(i + 1):
            line_j = lines[j]
            z_j = line_j.bias + line_j.beta[0] * grid_points[0] + line_j.beta[1] * grid_points[1]
            h_j = np.where(z_j >= 0.0, 1.0, -1.0)  # hard predictions: sign of the half-space
            ensemble_votes += line_j.alpha * h_j

        # Left: current weak learner's probability
        line_i = lines[i]
        z_i = line_i.bias + line_i.beta[0] * grid_points[0] + line_i.beta[1] * grid_points[1]
        p_i = sigmoid(z_i)

        Z_ensemble = ensemble_votes.reshape(xx.shape)
        Z_current = p_i.reshape(xx.shape)

        # Current learner's alpha normalized by cumulative alpha
        norm_w = line_i.alpha / (cum_alpha[i] if cum_alpha[i] else 1.0)

        # Predictions on training data (for styling)
        z_train = line_i.bias + line_i.beta[0] * X[0] + line_i.beta[1] * X[1]
        p_train = sigmoid(z_train)
        current_line_preds = (p_train >= 0.5).astype(int)

        # Ensemble predictions on training data
        ensemble_votes_train = np.zeros(X.shape[1], dtype=float)
        for j in range(i + 1):
            line_j = lines[j]
            z_j_train = line_j.bias + line_j.beta[0] * X[0] + line_j.beta[1] * X[1]
            h_j_train = np.where(z_j_train >= 0.0, 1.0, -1.0)
            ensemble_votes_train += line_j.alpha * h_j_train
        ensemble_preds = np.where(ensemble_votes_train >= 0, 1, 0)

        # Plot
        fig, (ax_l, ax_r) = plt.subplots(1, 2, figsize=(18, 8))
        plt.rcParams.update(PLOT_SETTINGS['rcParams'])

        colors_pts = ['red' if int(label) == 1 else 'blue' for label in y]

        # Left: current weak learner (probability + 0.5 contour)
        ax_l.tick_params(axis='both', which='major', labelsize=12)
        contour_l = ax_l.contourf(xx, yy, Z_current, levels=PLOT_SETTINGS['contour_levels'],
                                  alpha=PLOT_SETTINGS['alpha'], cmap=PLOT_SETTINGS['cmap'])
        ax_l.contour(xx, yy, Z_current, levels=[0.5], colors='black', linewidths=2)
        _scatter_points_with_classification_status(ax_l, X, y, current_line_preds, colors_pts)
        ax_l.set_xlim(x_min, x_max)
        ax_l.set_ylim(y_min, y_max)
        ax_l.set_xlabel('X1', fontsize=16, fontweight='bold')
        ax_l.set_ylabel('X2', fontsize=16, fontweight='bold')
        ax_l.set_title(f'Current weak learner #{i + 1}\nalpha={line_i.alpha:.3f}, normalized={norm_w:.3f}',
                       fontsize=16, fontweight='bold', pad=12)
        cbar_l = plt.colorbar(contour_l, ax=ax_l)
        cbar_l.set_label('Sigmoid probability', fontsize=14, fontweight='bold')

        # Right: ensemble (hard vote + 0-level contour; piecewise boundary)
        ax_r.tick_params(axis='both', which='major', labelsize=12)
        contour_r = ax_r.contourf(xx, yy, Z_ensemble, levels=PLOT_SETTINGS['contour_levels'],
                                  alpha=PLOT_SETTINGS['alpha'], cmap=PLOT_SETTINGS['cmap'])
        ax_r.contour(xx, yy, Z_ensemble, levels=[0.0], colors='black', linewidths=2)
        ax_r.contour(xx, yy, Z_current, levels=[0.5], colors='gray', linewidths=1,
                     linestyles='--', alpha=0.7)  # reference to current plane
        _scatter_points_with_classification_status(ax_r, X, y, ensemble_preds, colors_pts)
        ax_r.set_xlim(x_min, x_max)
        ax_r.set_ylim(y_min, y_max)
        ax_r.set_xlabel('X1', fontsize=16, fontweight='bold')
        ax_r.set_ylabel('X2', fontsize=16, fontweight='bold')
        ax_r.set_title(f'Ensemble after {i + 1} learners (α-weighted votes)',
                       fontsize=16, fontweight='bold', pad=12)
        cbar_r = plt.colorbar(contour_r, ax=ax_r)
        cbar_r.set_label('Ensemble votes', fontsize=14, fontweight='bold')

        frames.append(canvas_to_rgb_array(fig))
        plt.close(fig)

    export_pdf_and_gif(frames, output_dir / f"{output_name}.pdf",
                       output_dir / f"{output_name}.gif")

    return frames
