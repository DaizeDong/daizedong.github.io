import random

import numpy as np


def sigmoid(eta):
    """
    The sigmoid function.
    """
    return 1 / (1 + np.exp(-eta))


def logistic_regression(X, y, weights, learning_rate=1.0, epochs=200):
    """
    Performs logistic regression to draw a decision boundary through
    (hopefully) linearly separable data.

    Args:
        X (float): Input data
        y (int): Target y class
        learning_rate (float): Update rate
        epochs (int): Number of times to iterate through the data
    """
    X = X.T
    n_samples, n_features = X.shape

    # Weights and bias
    random_scaler = 10 * random.random()
    beta = np.random.randn(n_features) * random_scaler
    bias = 0

    # Gradient descent
    for i in range(epochs):
        # Get the predicted probabilities
        y_hat = sigmoid(X @ beta + bias)
        weighted_error = weights * (y_hat - y)

        # Calculate gradients w.r.t. w and b
        # Average over the size of the dataset
        dw = (1 / len(y)) * weighted_error @ X
        db = (1 / len(y)) * np.sum(weighted_error)

        # Update w
        beta -= learning_rate * dw
        bias -= learning_rate * db

        # print(f"epoch {i} error is {np.mean(weighted_error):.4f}")

    return beta, bias


def logistic_predict(beta, bias, X):
    return sigmoid(X.T @ beta + bias).round().astype(int)


class regressor():
    def __init__(self, beta, bias):
        self.beta = beta
        self.bias = bias
        self.alpha = None
        self.error = None

    def predict(self, X):
        return logistic_predict(self.beta, self.bias, X)


def fitRegression(X, y, num_lines, seed=None):
    columns, samples = X.shape
    # Equally weight all samples to begin
    weights = np.full(samples, 1 / samples)
    print(f"initial line weights {weights}")

    # If a seed is provided, make the regression training deterministic
    if seed is not None:
        random.seed(seed)
        np.random.seed(seed)

    lines = []

    for t in range(num_lines):
        beta, bias = logistic_regression(X, y, weights)
        line = regressor(beta, bias)
        y_hat = line.predict(X)
        error_mask = (y != y_hat)

        # Convert to 1, -1 predictions for adaboost math
        y_pred = np.where(y_hat == 1, 1, -1)

        weighted_error = np.sum(weights[error_mask])
        line.error = weighted_error

        # Same as the stump code, for the most part
        # Calculate confidence factor of the line
        alpha = 0.5 * np.log((1.0 - line.error) / (line.error + 1e-10))
        line.alpha = alpha
        lines.append(line)
        # We predict 0 and 1 instead of -1 and 1, so there is no cute multiply trick.
        # Populate an array with alpha and -alpha
        adjustments = np.where(error_mask, alpha, -alpha)
        weights *= np.exp(adjustments) # update factor

        # Ensure weights sum to 1
        weights /= np.sum(weights)

        print(f"line {t} weights {weights}")
        print(f"line {t} error {line.error}")
        print(f"line {t} y predictions {y_hat}")
        print(f"line {t} alpha {line.alpha}")
        print(f"line {t} parameters {line.bias} {line.beta}")
    return lines


def predictLines(lines, X):
    num_samples = X.shape[1]

    y_hat_sums = np.zeros(num_samples)

    alpha_sum = 0

    for line in lines:
        y_hats = line.predict(X)
        y_hat_sums += line.alpha * y_hats
        alpha_sum += line.alpha

    predictions = (y_hat_sums / alpha_sum).round().astype(int)
    return predictions
