# run.py
import argparse
import sys

import numpy as np

import regression_funcs
import stump_funcs
import visualization


def _to_int_array(a):
    return np.asarray(a, dtype=int)


def printClassStatistics(y_true, y_pred):
    """Print simple binary classification statistics for labels in {0,1}."""
    y_true = _to_int_array(y_true)
    y_pred = _to_int_array(y_pred)

    if y_true.shape != y_pred.shape:
        raise ValueError("y_true and y_pred must have the same shape")

    tp = int(np.sum((y_true == 1) & (y_pred == 1)))
    tn = int(np.sum((y_true == 0) & (y_pred == 0)))
    fp = int(np.sum((y_true == 0) & (y_pred == 1)))
    fn = int(np.sum((y_true == 1) & (y_pred == 0)))

    total = len(y_true)
    accuracy = (tp + tn) / total if total else 0.0
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) else 0.0

    print("Confusion matrix (rows=true, cols=pred):")
    print(f"  TN={tn}  FP={fp}")
    print(f"  FN={fn}  TP={tp}")
    print(f"accuracy={accuracy:.4f} precision={precision:.4f} recall={recall:.4f} f1={f1:.4f}")


def read_spambase(data_file):
    """
    Generic CSV reader: the last column is y (labels), all previous columns are X.
    Rows map to features and columns to samples (unpack=True yields X with shape (features, samples)).
    Works with your example data that has a header row.
    """
    try:
        data = np.loadtxt(data_file, delimiter=',', skiprows=1, unpack=True)
    except FileNotFoundError:
        print(f"Error: The file '{data_file}' was not found.")
        sys.exit(1)
    except ValueError:
        print(f"Error: The file '{data_file}' does not contain valid numeric data.")
        sys.exit(1)

    return data[:-1], data[-1]


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("path", type=str,
                        help="Path to CSV file. The last column is the label; preceding columns are features.")
    parser.add_argument("--model", choices=["stumps", "regression"], default="stumps",
                        help="Which weak learners to use: decision stumps or logistic regression.")
    parser.add_argument("--kstumps", type=int, default=8,
                        help="Number of AdaBoost weak learners (stumps or regressors).")
    parser.add_argument("--output-dir", type=str, default="output",
                        help="Directory to save visualizations (default: 'output').")
    parser.add_argument("--output-name", type=str, default=None,
                        help="Output file name prefix (without extension). Defaults to a model-specific name.")
    parser.add_argument("--seed", type=int, default=None,
                        help="Random seed for regression training (optional). Makes regression deterministic when provided.")
    args = parser.parse_args()

    X, y = read_spambase(args.path)
    X_train = X
    y_train = y.astype(int)

    if args.model == "stumps":
        print(f"Training AdaBoost with {args.kstumps} stumps")
        stumps = stump_funcs.fitStumps(X_train, y_train * 2 - 1, args.kstumps)
        train_predictions = ((stump_funcs.predictStumps(stumps, X_train) + 1) // 2).astype(int)

        # Training accuracy
        print(f"predictions are {train_predictions}")
        print(f"true classes are {y_train}")
        acc = np.mean(train_predictions == y_train)
        print(f"AdaBoost train accuracy {args.kstumps} stumps {acc:.4f}")

        alphas = [stump.alpha for stump in stumps]
        print(f"alphas={alphas}")

        # Visualization
        print("Creating stump decision boundary visualization...")
        output_name = args.output_name if args.output_name else "adaboost_stump_decision_boundary"
        visualization.create_stump_decision_boundary_visualization(X_train, y_train, stumps,
                                                                   args.output_dir, output_name)

    else:
        print(f"Training AdaBoost with {args.kstumps} regressions")
        lines = regression_funcs.fitRegression(X_train, y_train, args.kstumps, seed=args.seed)
        train_predictions = regression_funcs.predictLines(lines, X_train).astype(int)

        # Training accuracy
        print(f"predictions are {train_predictions}")
        print(f"true classes are {y_train}")
        acc = np.mean(train_predictions == y_train)
        print(f"AdaBoost train accuracy {args.kstumps} regressions {acc:.4f}")

        alphas = [line.alpha for line in lines]
        print(f"alphas={alphas}")

        # Visualization
        print("Creating decision boundary visualization...")
        output_name = args.output_name if args.output_name else "adaboost_regression_decision_boundary"
        visualization.create_regression_decision_boundary_visualization(X_train, y_train, lines,
                                                                        args.output_dir, output_name)

    print("Train statistics.")
    printClassStatistics(y_train, train_predictions)
