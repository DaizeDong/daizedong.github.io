# CS461 Recitation 06 - AdaBoost Stump & Regression Demo

_Daize Dong, Rutgers University, Oct 20, 2025_

## Overview

Today we will be working on a compact demo of AdaBoost with two types of weak learners:

- **Decision stumps** (1D thresholds producing labels in {-1, +1}).
- **Logistic-regression lines** (binary logistic regression producing {0,1}).

The code visualizes both the current weak learner and the ensemble decision boundary at each boosting step, exporting both PDF and GIF sequences.

## Data format

CSV with a header row. The last column is the label `y` (0/1). All previous columns are features.  
The loader reads data as `(X, y)` where `X` has shape `(features, samples)`.

## Usage

Train and visualize stumps:

```bash
python run.py path/to/data.csv --model stumps --kstumps 8 --output-dir output --output-name stumps
```

Train and visualize logistic regression lines:

```bash
python run.py path/to/data.csv --model regression --kstumps 8 --output-dir output --output-name regression
```
