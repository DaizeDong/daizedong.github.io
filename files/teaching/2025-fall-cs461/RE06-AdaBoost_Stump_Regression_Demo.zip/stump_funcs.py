# stump_funcs.py
import numpy as np


class Stump:
    def __init__(self, feature_index, threshold, polarity, alpha):
        self.feature_index = feature_index
        self.threshold = threshold
        # polarity meaning:
        #   1  -> left side is -1
        #  -1  -> right side is -1
        self.polarity = polarity
        self.alpha = float(alpha)


def _predict_single(stump, X):
    """Predict {-1, +1} for a single stump on all samples.

    Args:
        stump (Stump): A trained decision stump.
        X (np.ndarray): Feature matrix (features, samples).
    """
    feature = X[stump.feature_index]
    preds = np.ones(feature.shape[0], dtype=int)
    if stump.polarity == 1:
        preds[feature < stump.threshold] = -1
    else:
        preds[feature >= stump.threshold] = -1
    return preds  # {-1, +1}


def predictStumps(stumps, X):
    """Alpha-weighted sign vote over multiple stumps."""
    agg = np.zeros(X.shape[1], dtype=float)
    for s in stumps:
        agg += s.alpha * _predict_single(s, X)
    return np.where(agg >= 0.0, 1, -1)


def fitStumps(X, y_pm1, num_stumps):
    """
    Train a sequence of decision stumps with AdaBoost.

    Args:
        X (np.ndarray): Feature matrix (features, samples).
        y_pm1 (np.ndarray): Labels in {-1, +1}.
        num_stumps (int): Number of weak learners.

    Returns:
        list[Stump]: The trained stumps with their alpha values.
    """
    features, samples = X.shape
    weights = np.full(samples, 1.0 / samples)
    stumps = []

    for _ in range(num_stumps):
        best_err = np.inf
        best = None
        best_preds = None

        for f in range(features):
            values = X[f]
            uniq = np.unique(values)
            # Candidate thresholds: midpoints of adjacent unique values
            # (avoid placing the threshold exactly on a training sample).
            thr_candidates = ((uniq[:-1] + uniq[1:]) / 2.0) if uniq.size > 1 else uniq

            for thr in thr_candidates:
                for polarity in (1, -1):
                    preds = np.ones(samples, dtype=int)
                    if polarity == 1:
                        preds[values < thr] = -1
                    else:
                        preds[values >= thr] = -1
                    err = float(np.sum(weights[preds != y_pm1]))
                    if err < best_err:
                        best_err = err
                        best = (f, thr, polarity)
                        best_preds = preds

        # If error > 0.5, flip the stump
        f, thr, pol = best
        if best_err > 0.5:
            best_err = 1.0 - best_err
            pol = -pol
            best_preds = -best_preds

        # Compute alpha with clamped error
        err = min(max(best_err, 1e-12), 1 - 1e-12)
        alpha = 0.5 * np.log((1.0 - err) / err)

        stump = Stump(f, thr, pol, alpha)
        stumps.append(stump)

        # AdaBoost weight update
        weights *= np.exp(-alpha * y_pm1 * best_preds)
        weights /= np.sum(weights)

    return stumps
