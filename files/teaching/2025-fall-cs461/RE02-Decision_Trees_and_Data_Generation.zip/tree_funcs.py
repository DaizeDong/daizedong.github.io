import numpy as np


def str_equal(left, right):
    return left == right


def str_nequal(left, right):
    return left != right


def num_lt(left, right):
    return left < right


def num_gte(left, right):
    return left >= right


def gini_impurity(classlist):
    """Return the square root of the gini impurity of this class list."""
    # We can't test with 0 instances
    if len(classlist) == 0:
        return 0.

    # Get the unique classes and the counts for each class
    classes, counts = np.unique(classlist, return_counts=True)
    p_hats = counts / len(classlist)
    gini = 1.0 - np.sum(p_hats ** 2)
    return np.sqrt(gini)


def get_best_impurity(column, classlist, comparison_left, comparison_right):
    """Search the values in the column to find the lowest impurity split of the classlist.
    Arguments:
        column (list[str or float]]): Columns of numeric or string data.
        classlist  (list[str]: Class labels for each row
        comparison_left  ((left, right) -> bool): Function that compares two column values.
        comparison_right ((left, right) -> bool): Function that compares two column values.

    Returns:
        (float, float, ([int], [int])): Tuple of the best impurity, its split threshold,
                                        and the indices for the two sides of the split.
    """

    best_impurity = float('inf')
    best_threshold = None
    split_indices = None

    # Find unique values
    values = np.unique(column)

    # Test unique values for split effectiveness
    for value in values:
        left_comparisons = [comparison_left(value, x) for x in column]
        right_comparisons = [comparison_right(value, x) for x in column]
        left_indices = np.asarray(left_comparisons).nonzero()[0]
        right_indices = np.asarray(right_comparisons).nonzero()[0]
        # Now find gini impurity
        left_impurity = gini_impurity([classlist[index] for index in left_indices])
        right_impurity = gini_impurity([classlist[index] for index in right_indices])
        weighted_impurity = (len(left_indices) / len(classlist)) * left_impurity + \
                            (len(right_indices) / len(classlist)) * right_impurity
        if weighted_impurity < best_impurity:
            best_impurity = weighted_impurity
            best_threshold = value
            split_indices = (left_indices, right_indices)
    return best_impurity, best_threshold, split_indices


def get_split(columns, classlist):
    """Search the columns to find the lowest impurity split of the classlist.
    Arguments:
        columns (list[list]]): Columns of numeric and string data.
        classlist  (list[str]: Class labels for each row

    Returns:
        (int, float or str): Tuple of the best feature index, its split threshold,
                             and the indices for the two sides of the split.
    """
    best_impurity = float('inf')
    best_index = None
    best_threshold = None
    best_indices = None

    for index, column in enumerate(columns):
        if type(column[0]) == float:
            impurity, threshold, indices = get_best_impurity(column, classlist, num_lt, num_gte)
        else:
            impurity, threshold, indices = get_best_impurity(column, classlist, str_equal, str_nequal)
        if impurity < best_impurity:
            best_impurity = impurity
            best_index = index
            best_threshold = threshold
            best_indices = indices

    return best_index, best_threshold, best_indices


class Node:
    def __init__(self, feature_index, boundary, comparison_left, comparison_right, class_name=None, lchild=None, rchild=None):
        self.feature_index = feature_index
        self.boundary = boundary
        self.comparison_left = comparison_left
        self.comparison_right = comparison_right
        self.class_name = class_name
        self.lchild = lchild
        self.rchild = rchild
        # -----------------------------------------------------------
        # You may add additional attributes if you wish
        # hint: for data generation, you may traverse from bottom to top
        # -----------------------------------------------------------

    def decide(self, data):
        """Return the classes of the rows in data.
        Arguments:
            data (list[list]]): Columns of numeric and string data.
        Returns:
            results (list[str]): List of class labels for each row.
        """
        results = []
        # -----------------------------------------------------------
        # TODO:
        # 1. If this is a leaf node, return the class_name for each row
        # 2. Otherwise, split the data based upon the feature_index and boundary
        # 3. Recursively call decide on the left and right children
        # 4. Combine the results and return them in the correct order
        # -----------------------------------------------------------
        return results


def build_decision_tree(columns, classlist):
    """Build a decision tree and return the root node.
    Arguments:
        columns (list[list]]): Columns of numeric and string data.
        classlist  (list[str]: Class labels for each row
    Returns:
        root (Node): Root node of the decision tree.
    """
    root = None
    # -----------------------------------------------------------
    # TODO:
    # 1. Check for base cases (all same class or no data)
    # 2. Use `get_split` to find the best feature and threshold
    # 3. Recursively build left and right subtrees (remember to add the stopping criteria)
    # 4. Return the root node
    # -----------------------------------------------------------
    return root


def read_csv(path):
    with open(path, 'r') as datafile:
        header_row = datafile.readline().strip('\n')
        column_names = [name.strip(' ') for name in header_row.split(',')]
        data = [[] for _ in column_names]
        for line in datafile:
            row_data = [entry.strip(' ') for entry in line.split(',')]
            for idx, entry in enumerate(row_data):
                try:
                    # Numerical value
                    number = float(entry)
                    data[idx].append(number)
                except ValueError:
                    # String value (for tabular data)
                    data[idx].append(entry)
            # Error checking
            assert all([len(data[0]) == len(data[i]) for i in range(1, len(data))])
    return data, column_names

# -----------------------------------------------------------
# TODO:
# You may add additional functions for data generation
# -----------------------------------------------------------
