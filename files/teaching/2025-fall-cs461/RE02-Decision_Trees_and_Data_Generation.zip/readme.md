# 461 Recitation 02 - Decision Trees & Data Generation

_Daize Dong, Rutgers University, Sep 22, 2025_

## Overview

Today we will be working on a programming assignment that involves:

1. Building a decision tree classifier.
2. Generating synthetic data based on the tree structure.

The assignment is designed to help you understand decision trees and how they can be used for classification and data generation.

## Arrangement

- Assignment overview
    - Recursive tree building
    - Synthetic data generation
- Code review
- QA

## Hint on Coding

- First split the data into training and testing sets.
- Implement the decision tree using a `Node` class to represent each node in the tree, storing necessary information such as column names, threshold, left/right children, parent, and class labels.
- When building the decision tree, consider using a recursive function that splits the data based on the best feature at each node.
- For synthetic data generation, traverse the tree from a random leaf node up to the root, estimating feature values along the way.
- Make sure to handle edge cases, such as when a leaf node has too few samples.

## References

Online Canvas: [01:198:461:06 ML PRINCIPLES - Assignments - Homework 1](https://rutgers.instructure.com/courses/376322/assignments/3952678)

Local Guide: [assignment1.md](assignment1.md)
