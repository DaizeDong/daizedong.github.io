# Homework 1

### Introduction

Machine learning is used in more than regression and classification tasks. One of the most popular applications used today is generation, as in large language models. Generating outputs that mimic the variance of a natural process is difficult, especially when humans are the judges of the output. Simply taking the population statistics and using them to generate new samples ignores correlations between variables. At best, this may result in comical samples in the generated set; at worst, the samples may be easily confused with members of other populations. ![An example penguin decision tree.](./example_decision_tree.png)

One simple method (not necessarily the best method) is to use a decision tree to generate new synthetic values. Think of the leaf nodes on a decision tree as unique populations. Members of the population ended up in different leaf nodes because something about them is different. If the statistics of a leaf node are used to generate new synthetic members of a population, then we can be fairly confident that they will not be confused with members of other populations, so long as we make sure to follow the rules of the decision tree.

Your homework is to build a decision tree. You may use the node class and any other code from class, or start from scratch. Note that we rushed the node slightly; when classifying multiple rows at a time, it should interleave the results together at the end of the `decide` function as follows:

```python
def decide(self, data):
    # (Separate the data into two groups by this node)
    # ...
    # Recursively descend
    lresults = self.lchild.decide(left_side)
    rresults = self.rchild.decide(right_side)
    # Now place the results into the correct indices to return
    results = []
    lindex = 0
    rindex = 0
    for index in range(len(data[0])):
        # See where the original index was mapped
        if index in left_indices:
            results.append(lresults[lindex])
            lindex += 1
        else:
            results.append(rresults[rindex])
            rindex += 1
    return results
```

### Instructions

**The synthetic penguin generation should proceed as follows.**

**Your program will accept 4 arguments followed by a list of strings:**

1. The name of a CSV file (the penguin data).
2. Either the string `“classify”` or the string `“generate”`.
3. A second CSV file to classify if `“classify”`, **OR** the number of synthetic penguins to generate if `“generate”`.
4. A column name to use as the prediction target (y). This is the name that appears on the first row of the CSV.
5. A list of the column names to use as the features (X).

For simplicity, simply accept them from `sys.arg`. There is no need to use `argparse`.

**Your program should do the following:**

When classifying:

1. Build a decision tree to classify the given column of data.
2. Classify each row of the second CSV, printing out the predicted classes one per row.

When generating:

The core idea is to traverse from the bottom (leaf) to the top (root), and sample one statistic (column) from each node.

1. Build a decision tree to classify the given column of data.
2. Select a _random leaf_ `Leaf` with the probability equal to the total penguin population that it was used to classify. Verify that it is used to classify a population of at least 2 penguins; if not, go to step 3 from _the parent node of this leaf_ `Leaf.parent` and use that parent instead of this leaf, but take the class label from `Leaf`.
3. Check the feature that was used to **divide** the penguins at the current node by looking at the parent node. In our example code, this would be the `feature_index` of the parent node. If we have not already made an estimate of those statistics, then estimate that feature using the statistics of the current node. The intuition is that the parent node divided this population from the rest with that feature, so our current population is representative of the class at the leaf.
4. Move to the parent node and repeat from step 3. When there is no parent node, move to step 5.
5. For any features that were not estimated, use the population of the leaf node to estimate the statistics.

You may use any LLM tool to assist with the assignment, but you must save all conversations and submit them with your code.

### Discussion

Why don’t we just use the population of the leaves to estimate the values for a synthetic penguin? The leaf nodes may not have many members, so the estimates of the variance for the different statistics could be quite bad. By checking the parent nodes, we risk mixing in statistics from other populations, but we also use them to get a better estimate of the natural variance of that characteristic. A more robust approach could try searching neighboring leaves for more members of the same species of penguin and using them to form a population estimate rather than the parent nodes.

However, if we look at our decision tree, we notice that one of our last decisions is based upon the sex of the penguin. It could be the case, for bill depth at least, that female chinstrap and adelie penguins are more similar than adelie male and female penguins. The goal of this approach is to capture some of the trait covariance of the subpopulations without getting stuck with tiny subpopulations where estimation will be impossible.

This approach works well enough so long as we have enough penguins filling the leaf nodes. If the data wasn’t very separable, then we’ll end up with a lot of rules making very small data splits, and we will have leaf nodes with only one or two penguins, which will not provide sufficient statistics. The penguin species is very separable though, so it isn’t a concern for that feature. Take note though, that I may test with the other non-numeric features as well, so you should test your code to be sure that it works on them.

Note that you will need to modify the Node class to hold enough information to generate your synthetic penguins.

### Evaluation

- 60% credit is for building a decision tree.
- 30% credit is for synthetic penguin generation. For full credit, you must use the leaf-up approach.
- 10% credit is for code comments and clarification.

**Example executions for classifying:**

```shell
python3 hw01.py \
  filtered_penguins_train.csv \
  classify \
  filtered_penguins_test.csv \
  species \
  island bill_length_mm bill_depth_mm flipper_length_mm body_mass_g sex
```

The output should be the predicted classes of filtered_penguins_test.csv, one per line.

**Example executions for generating:**

```shell
python3 hw01.py \
  filtered_penguins_train.csv \
  generate \
  100 \
  species \
  island bill_length_mm bill_depth_mm flipper_length_mm body_mass_g sex
```

The output should be a header row with the y column and X column names, followed by the specified number of synthetic penguins.

**Example data formats:**

```csv
species, island, bill_length_mm, bill_depth_mm, flipper_length_mm, body_mass_g, sex
(100 rows of penguins follows)
```

**Notes:**

We will be discussing clustering in the upcoming class. When your synthetic penguins are tested with the clustering of KNN, the majority should join the correct cluster of original penguins, even with different combinations of rows.

None of your synthetic penguins should be equal in value to any existing penguin or other synthetic penguins–they must be randomly generated, and the chance of multiple random values being equal is vanishingly small.

### Submission

Submit your Python files, with your `__main__` function in `hw01.py`.

Also, submit logs of any LLM sessions as related to this assignment. Please take care not to submit logs of other, unrelated sessions.

Data source: [allisonhorst/palmerpenguins: A great intro dataset for data exploration & visualization (alternative to iris).](https://github.com/allisonhorst/palmerpenguins)
