import sys

import tree_funcs


def print_tree_structure(root):
    print("Decision Tree Structure:")
    node_list = [root]
    node_name = ["root"]
    while node_list:
        node = node_list.pop(0)
        name = node_name.pop(0)
        print(
            f"Node name: {name}, Feature index: {node.feature_index}, "
            f"boundary: {node.boundary}, class: {node.class_name}"
        )
        if node.lchild is not None:
            node_list.append(node.lchild)
            node_name.append(f"{name}L")
        if node.rchild is not None:
            node_list.append(node.rchild)
            node_name.append(f"{name}R")


def main():
    """
    Usage:
      python script.py <data_csv> <classify|generate> <second> <y_col> <X_col1> [<X_col2> ...]
        - <data_csv>: path to training CSV
        - <classify|generate>:
            * classify -> <second> is a CSV to classify (will print predictions)
            * generate -> <second> is an integer: number of synthetic rows to generate (prints CSV to stdout)
        - <y_col>: target column name (exactly as in the CSV header)
        - <X_col*>: one or more feature column names (exactly as in the CSV header)
    """
    if len(sys.argv) < 6:
        raise SystemExit(
            "Args: <train_csv> <classify|generate> <second> <y_col> <X_col1> [<X_col2> ...]"
        )

    train_csv = sys.argv[1]
    mode = sys.argv[2].lower()
    second = sys.argv[3]
    y_name = sys.argv[4]
    X_names = sys.argv[5:]

    # Load training data
    records, column_names = tree_funcs.read_csv(train_csv)
    name_to_idx = {name: i for i, name in enumerate(column_names)}

    # Validate requested columns
    if y_name not in name_to_idx:
        raise SystemExit(f"Target column '{y_name}' not found in {train_csv}.")
    for xn in X_names:
        if xn not in name_to_idx:
            raise SystemExit(f"Feature column '{xn}' not found in {train_csv}.")

    # Slice columns by name
    y = records[name_to_idx[y_name]]
    X = [records[name_to_idx[xn]] for xn in X_names]

    # Train tree
    root = tree_funcs.build_decision_tree(X, y)
    print_tree_structure(root)

    # Act based on mode
    if mode == "classify":
        # Classify a second CSV (may or may not have y)
        test_records, test_cols = tree_funcs.read_csv(second)
        test_name_to_idx = {n: i for i, n in enumerate(test_cols)}

        # -----------------------------------------------------------
        # TODO:
        # 1. Check features exist
        # 2. Slice features into X_test
        # 3. Call root.decide(X_test) to get predictions, and calculate accuracy
        # 4. Print predictions
        # -----------------------------------------------------------

    elif mode == "generate":
        # Generate N synthetic rows:
        #   Simple product-of-marginals sampler for X, then label with the trained tree.
        try:
            n = int(second)
        except ValueError:
            raise SystemExit("For 'generate', the third argument must be an integer (count).")

        # -----------------------------------------------------------
        # TODO:
        # You should write a new function in tree_funcs.py to do the generation.
        # 1. For each feature column, sample n values with replacement
        #    (you can use random.choices for this)
        # 2. Call root.decide on the generated X to get predicted classes, and calculate accuracy
        # 3. Print a CSV to stdout with header and n rows of generated data
        # -----------------------------------------------------------

    else:
        raise SystemExit("Second argument must be 'classify' or 'generate'.")


if __name__ == "__main__":
    main()
