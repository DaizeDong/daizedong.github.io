import argparse
import os
import pickle
from pathlib import Path
from typing import Dict, List

import numpy as np
import torch
from PIL import Image

from resnet import ResNet, preprocess


def load_digit_image(path: str | os.PathLike) -> np.ndarray:
    img = Image.open(path).convert("L")
    arr = np.array(img, dtype=np.float32) / 255.0
    if arr.shape != (28, 28):
        raise ValueError(f"Expected image of shape (28, 28), got {arr.shape} from {path}")
    return arr


def make_blends(first: np.ndarray, second: np.ndarray, num_steps: int = 20) -> np.ndarray:
    if first.shape != second.shape:
        raise ValueError(f"Shape mismatch: {first.shape=} vs {second.shape=}")
    blends: List[np.ndarray] = []
    for i in range(num_steps):
        alpha = float(num_steps - i) / num_steps
        blend = first * alpha + second * (1.0 - alpha)
        blends.append(blend)
    return np.stack(blends, axis=0)


def load_resnet(path: str | os.PathLike, device: torch.device) -> ResNet:
    model = ResNet()
    try:
        state_dict = torch.load(path, map_location=device, weights_only=True)
    except TypeError:
        state_dict = torch.load(path, map_location=device)
    model.load_state_dict(state_dict)
    model.to(device)
    model.eval()
    return model


def load_svm(path: str | os.PathLike):
    with open(path, "rb") as f:
        svm = pickle.load(f)
    return svm


def compute_scores(
    data_tensor: torch.Tensor,
    model: ResNet,
    svm,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, Dict[int, np.ndarray], Dict[int, np.ndarray]]:
    with torch.no_grad():
        features = model.features(data_tensor).cpu().numpy()
        dnn_probs = model(data_tensor).cpu().numpy()
        dnn_pred = np.argmax(dnn_probs, axis=1)
    svm_decision = svm.decision_function(features)
    svm_pred = svm.predict(features)

    svm_scores_by_class: Dict[int, np.ndarray] = {}
    if svm_decision.ndim == 1:
        svm_scores_by_class[int(svm.classes_[1])] = svm_decision
    else:
        for idx, label in enumerate(svm.classes_):
            svm_scores_by_class[int(label)] = svm_decision[:, idx]

    dnn_scores_by_class: Dict[int, np.ndarray] = {}
    for label in range(dnn_probs.shape[1]):
        dnn_scores_by_class[label] = dnn_probs[:, label]

    return svm_decision, svm_pred, dnn_probs, dnn_pred, svm_scores_by_class, dnn_scores_by_class


def save_numpy_arrays(out_dir: str | os.PathLike, svm_decision: np.ndarray, svm_pred: np.ndarray, dnn_probs: np.ndarray, dnn_pred: np.ndarray) -> None:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    np.save(out_dir / "svm_decision.npy", svm_decision)
    np.save(out_dir / "svm_pred.npy", svm_pred)
    np.save(out_dir / "dnn_probs.npy", dnn_probs)
    np.save(out_dir / "dnn_pred.npy", dnn_pred)
    print(f"Saved numpy arrays to {out_dir}")


def save_blended_examples(blends: np.ndarray, out_dir: str | os.PathLike) -> None:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    num_steps = blends.shape[0]
    for step in range(num_steps):
        arr = (blends[step] * 255.0).clip(0, 255).astype(np.uint8)
        img = Image.fromarray(arr, mode="L")
        img_path = out_dir / f"blended_step_{step:03d}.png"
        img.save(img_path)
    print(f"Saved {num_steps} blended image(s) to {out_dir}")


def plot_scores(
    input_classes: List[int],
    all_predicted_classes: List[int],
    scores_by_class: Dict[int, np.ndarray],
    save_file: str,
    title: str = None,
    xlabel: str = None,
    ylabel: str = None,
) -> None:
    ############################################################
    # TODO: Plot SVM decision scores for different predicted classes
    # 1. Determine which classes to plot: input_classes and all_predicted_classes
    # 2. Identify the scores for each class from scores_by_class
    # 3. Identify the blend steps (0 to num_steps-1)
    # 4. Use matplotlib to create the plot
    # 5. Save the plot to save_file if provided
    ############################################################
    pass


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="CS461 HW5: blend digits, run ResNet+SVM, plot with Matplotlib")
    parser.add_argument("--first", required=True, help="Path to the first digit PNG.")
    parser.add_argument("--second", required=True, help="Path to the second digit PNG.")
    parser.add_argument("--load-dnn", required=True, help="Path to pretrained ResNet (.pyt).")
    parser.add_argument("--load-svm", required=True, help="Path to pretrained SVM (.pkl).")
    parser.add_argument("--num-steps", type=int, default=20, help="Number of blend steps between the two digits (default: 101).")
    parser.add_argument("--plot-svm-classes", action="store_true", help="Plot SVM scores for the two input digit classes.")
    parser.add_argument("--plot-dnn-classes", action="store_true", help="Plot DNN probabilities for the two input digit classes.")
    parser.add_argument("--save-blended-dir", type=str, default=None, help="Directory to save all outputs (npy files, PNG images, and plots).")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")

    print("Loading digit images...")
    first = load_digit_image(args.first)
    second = load_digit_image(args.second)

    print(f"Building blended images ({args.num_steps} steps)...")
    blends = make_blends(first, second, num_steps=args.num_steps)

    print("Preprocessing blended images...")
    order = np.arange(blends.shape[0])
    data_tensor = preprocess(blends, order, device)

    print("Loading pretrained DNN and SVM...")
    model = load_resnet(args.load_dnn, device=device)
    svm = load_svm(args.load_svm)

    print("Running classifiers on blended images...")
    svm_decision, svm_pred, dnn_probs, dnn_pred, svm_scores_by_class, dnn_scores_by_class = compute_scores(
        data_tensor, model, svm
    )

    print("Identifying input digit classes...")
    first_tensor = preprocess(first[np.newaxis, ...], np.array([0]), device)
    second_tensor = preprocess(second[np.newaxis, ...], np.array([0]), device)

    with torch.no_grad():
        first_features = model.features(first_tensor).cpu().numpy()
        first_dnn_probs = model(first_tensor).cpu().numpy()
        first_dnn_class = int(np.argmax(first_dnn_probs, axis=1)[0])
        first_svm_class = int(svm.predict(first_features)[0])

        second_features = model.features(second_tensor).cpu().numpy()
        second_dnn_probs = model(second_tensor).cpu().numpy()
        second_dnn_class = int(np.argmax(second_dnn_probs, axis=1)[0])
        second_svm_class = int(svm.predict(second_features)[0])

    input_classes = sorted(set([first_svm_class, second_svm_class]))
    if len(input_classes) < 2:
        input_classes = sorted(set([first_dnn_class, second_dnn_class]))

    print(f"Identified input classes: {input_classes} (SVM: {first_svm_class}, {second_svm_class}; DNN: {first_dnn_class}, {second_dnn_class})")

    steps = np.arange(blends.shape[0])
    print("=== Summary over all blend steps ===")
    print(f"{'Step':<6} | {'True Labels':<15} | {'SVM':<4} | {'DNN':<4}")
    print("-" * 40)
    for step in steps:
        true_labels = f"{first_svm_class}->{second_svm_class}"
        print(f"{step:<6} | {true_labels:<15} | {svm_pred[step]:<4} | {dnn_pred[step]:<4}")
    same_mask = svm_pred == dnn_pred
    print(f"\nNumber of steps where SVM and DNN agree: {same_mask.sum()} / {len(steps)}")

    if args.save_blended_dir is not None:
        out_dir = args.save_blended_dir
        Path(out_dir).mkdir(parents=True, exist_ok=True)
        print(f"Saving all outputs to {out_dir}...")
        save_numpy_arrays(out_dir, svm_decision, svm_pred, dnn_probs, dnn_pred)
        save_blended_examples(blends, out_dir)

    if args.plot_svm_classes:
        plot_scores(
            input_classes,
            sorted(set(svm_pred.astype(int).tolist())),
            svm_scores_by_class,
            save_file=str(Path(args.save_blended_dir) / "svm_scores.png") if args.save_blended_dir is not None else None,
            title=f"SVM decision scores: {os.path.basename(args.first)} -> {os.path.basename(args.second)}",
            xlabel="Blend step",
            ylabel="SVM decision score",
        )

    if args.plot_dnn_classes:
        plot_scores(
            input_classes,
            sorted(set(dnn_pred.astype(int).tolist())),
            dnn_scores_by_class,
            save_file=str(Path(args.save_blended_dir) / "dnn_probs.png") if args.save_blended_dir is not None else None,
            title=f"DNN predicted probabilities: {os.path.basename(args.first)} -> {os.path.basename(args.second)}",
            xlabel="Blend step",
            ylabel="DNN predicted probability",
        )


if __name__ == "__main__":
    main()
