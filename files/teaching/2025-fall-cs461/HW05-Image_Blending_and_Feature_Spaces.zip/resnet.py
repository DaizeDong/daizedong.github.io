import numpy as np
import torch
import torch.nn.functional as F
from torch import nn


class ResidualBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, nonlinearity: type[nn.Module] = nn.ReLU, stride: int = 1):
        super().__init__()
        self.residual = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nonlinearity(),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=stride, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
        )
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channels),
            )
        else:
            self.shortcut = nn.Sequential()
        self.nonlinearity = nonlinearity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.residual(x)
        x = self.shortcut(x)
        return self.nonlinearity(out + x)


class ResNet(nn.Module):
    def __init__(self, nonlinearity: type[nn.Module] = nn.ReLU) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(1, 16, kernel_size=5),
            nn.BatchNorm2d(16),
            nonlinearity(),
            ResidualBlock(16, 16),
            ResidualBlock(16, 16),
            ResidualBlock(16, 32, stride=2),
            ResidualBlock(32, 32),
            ResidualBlock(32, 32),
            ResidualBlock(32, 64, stride=2),
            ResidualBlock(64, 64),
            ResidualBlock(64, 64),
            ResidualBlock(64, 128, stride=2),
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(128, 84),
            nn.Linear(84, 10),
        )
        self.decision = nn.Softmax(dim=1)
        nn.init.uniform_(self.net[0].weight.data, a=-1.0, b=1.0)

    def features(self, x: torch.Tensor) -> torch.Tensor:
        for i in range(14):
            x = self.net[i](x)
        return x

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.decision(self.net(x))


def preprocess(x: np.ndarray, order: np.ndarray, device: torch.device) -> torch.Tensor:
    preprocessed = torch.tensor(1.175 - (1.275 * x[order]), dtype=torch.float32)
    preprocessed = F.pad(preprocessed, pad=(2, 2, 2, 2))
    return preprocessed.reshape((-1, 1, 32, 32)).to(device)
